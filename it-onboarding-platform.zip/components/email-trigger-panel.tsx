"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mail, Send, CheckCircle, Users, User, Building } from "lucide-react"

interface EmailTriggerPanelProps {
  employeeName: string
  employeeEmail: string
  processType: "onboarding" | "exit"
  currentStage: string
}

export function EmailTriggerPanel({ employeeName, employeeEmail, processType, currentStage }: EmailTriggerPanelProps) {
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [customMessage, setCustomMessage] = useState("")
  const [emailsSent, setEmailsSent] = useState<string[]>([])
  const [isSending, setIsSending] = useState(false)

  const emailTemplates = {
    onboarding: {
      welcome: {
        subject: "Welcome to the team! Your onboarding has started",
        content: `Dear ${employeeName},\n\nWelcome to our organization! Your onboarding process has been initiated.\n\nYou will receive updates as we prepare your workspace and accounts.\n\nBest regards,\nIT Team`,
      },
      hr_approval_needed: {
        subject: `HR approval required for ${employeeName} onboarding`,
        content: `A new onboarding request requires HR approval for ${employeeName}.\n\nPlease review and approve the request to proceed with asset assignment.`,
      },
      assets_assigned: {
        subject: `Assets assigned to ${employeeName}`,
        content: `Assets have been assigned to ${employeeName} and are ready for pickup.\n\nPlease coordinate with IT for device setup.`,
      },
      software_installation: {
        subject: `Software installation required for ${employeeName}`,
        content: `Please install the following software for ${employeeName}:\n\n• Microsoft Office Suite\n• Adobe Reader DC\n• WinRAR/7-Zip\n• VPN Client\n\nAll software should be ready by their start date.`,
      },
      accounts_created: {
        subject: `Email accounts created for ${employeeName}`,
        content: `Email accounts and system access have been created for ${employeeName}.\n\nCredentials will be provided on their first day.`,
      },
      onboarding_complete: {
        subject: `Onboarding completed for ${employeeName}`,
        content: `Great news! The onboarding process for ${employeeName} has been completed successfully.\n\nAll assets assigned, software installed, and accounts created.`,
      },
    },
    exit: {
      exit_initiated: {
        subject: "Exit process initiated - Important information",
        content: `Dear ${employeeName},\n\nYour exit process has been initiated.\n\nPlease ensure all company assets are returned and coordinate with IT for data backup if needed.\n\nThank you for your service.`,
      },
      asset_return_reminder: {
        subject: `Asset return required for ${employeeName}`,
        content: `Please ensure all company assets are returned by ${employeeName} before their exit date.\n\nThis includes laptops, monitors, keyboards, and access cards.`,
      },
      software_cleanup: {
        subject: `Software cleanup required for ${employeeName}`,
        content: `Please revoke software licenses and clean up systems for ${employeeName}:\n\n• Revoke Office 365 license\n• Deactivate Adobe licenses\n• Disable VPN access\n• Format devices securely`,
      },
      data_deletion: {
        subject: `Data deletion required for ${employeeName}`,
        content: `Please proceed with secure data deletion for ${employeeName}:\n\n• Delete email accounts\n• Remove cloud storage access\n• Clear application data\n• Format local storage`,
      },
      exit_complete: {
        subject: `Exit process completed for ${employeeName}`,
        content: `The exit process for ${employeeName} has been completed successfully.\n\nAll assets returned, software revoked, and data securely deleted.`,
      },
    },
  }

  const recipients = [
    {
      value: "employee",
      label: "Employee",
      email: employeeEmail,
      icon: <User className="h-4 w-4" />,
    },
    {
      value: "hr",
      label: "HR Team",
      email: "hr@company.com",
      icon: <Users className="h-4 w-4" />,
    },
    {
      value: "it",
      label: "IT Team",
      email: "it@company.com",
      icon: <Building className="h-4 w-4" />,
    },
    {
      value: "manager",
      label: "Manager",
      email: "manager@company.com",
      icon: <User className="h-4 w-4" />,
    },
  ]

  const handleRecipientToggle = (recipientValue: string) => {
    setSelectedRecipients((prev) =>
      prev.includes(recipientValue) ? prev.filter((r) => r !== recipientValue) : [...prev, recipientValue],
    )
  }

  const sendEmail = async (recipient: string, subject: string, content: string) => {
    // Simulate email sending with delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    console.log(`📧 Email sent to ${recipient}:`)
    console.log(`Subject: ${subject}`)
    console.log(`Content: ${content}`)
    console.log("---")

    return `${recipient} - ${subject}`
  }

  const handleSendEmails = async () => {
    if (selectedRecipients.length === 0 || !selectedTemplate) {
      alert("Please select recipients and a template")
      return
    }

    setIsSending(true)

    try {
      const template =
        emailTemplates[processType][selectedTemplate as keyof (typeof emailTemplates)[typeof processType]]
      const emailContent = customMessage || template.content

      const emailPromises = selectedRecipients.map(async (recipientValue) => {
        const recipient = recipients.find((r) => r.value === recipientValue)
        if (recipient) {
          return await sendEmail(recipient.email, template.subject, emailContent)
        }
      })

      const sentEmails = await Promise.all(emailPromises)
      setEmailsSent((prev) => [...prev, ...(sentEmails.filter(Boolean) as string[])])

      alert(`✅ Emails sent successfully to ${selectedRecipients.length} recipient(s)!`)

      // Clear form
      setSelectedTemplate("")
      setCustomMessage("")
      setSelectedRecipients([])
    } catch (error) {
      console.error("Error sending emails:", error)
      alert("❌ Error sending emails. Please try again.")
    } finally {
      setIsSending(false)
    }
  }

  const currentTemplates = emailTemplates[processType]

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Mail className="h-5 w-5 mr-2 text-blue-600" />
          Email Trigger Panel
        </CardTitle>
        <CardDescription>
          Send email notifications for {processType} process - Current Stage: {currentStage}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Recipient Selection */}
        <div>
          <label className="text-sm font-medium mb-3 block">Select Recipients:</label>
          <div className="grid grid-cols-2 gap-2">
            {recipients.map((recipient) => (
              <div
                key={recipient.value}
                onClick={() => handleRecipientToggle(recipient.value)}
                className={`p-3 border rounded-lg cursor-pointer transition-all ${
                  selectedRecipients.includes(recipient.value)
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="flex items-center space-x-2">
                  {recipient.icon}
                  <div>
                    <p className="text-sm font-medium">{recipient.label}</p>
                    <p className="text-xs text-gray-500">{recipient.email}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2">{selectedRecipients.length} recipient(s) selected</p>
        </div>

        {/* Template Selection */}
        <div>
          <label className="text-sm font-medium mb-2 block">Email Template:</label>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder="Choose an email template" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(currentTemplates).map(([key, template]) => (
                <SelectItem key={key} value={key}>
                  {template.subject}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Template Preview */}
        {selectedTemplate && (
          <div className="p-3 bg-gray-50 border rounded-lg">
            <p className="text-sm font-medium mb-1">Template Preview:</p>
            <p className="text-xs text-gray-600 mb-2">
              Subject: {currentTemplates[selectedTemplate as keyof typeof currentTemplates].subject}
            </p>
            <p className="text-xs text-gray-600 whitespace-pre-line">
              {currentTemplates[selectedTemplate as keyof typeof currentTemplates].content}
            </p>
          </div>
        )}

        {/* Custom Message */}
        <div>
          <label className="text-sm font-medium mb-2 block">Custom Message (Optional):</label>
          <Textarea
            placeholder="Override the template with a custom message..."
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            rows={4}
          />
        </div>

        {/* Send Button */}
        <Button
          onClick={handleSendEmails}
          disabled={selectedRecipients.length === 0 || !selectedTemplate || isSending}
          className="w-full"
        >
          <Send className="h-4 w-4 mr-2" />
          {isSending ? "Sending..." : `Send Email to ${selectedRecipients.length} Recipient(s)`}
        </Button>

        {/* Email Activity Log */}
        {emailsSent.length > 0 && (
          <div className="border-t pt-4">
            <p className="text-sm font-medium mb-3 flex items-center">
              <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
              Recent Email Activity:
            </p>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {emailsSent.slice(-5).map((email, index) => (
                <div key={index} className="p-2 bg-green-50 border border-green-200 rounded text-xs">
                  <div className="flex items-center justify-between">
                    <span>✅ {email}</span>
                    <span className="text-gray-500">{new Date().toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
            {emailsSent.length > 5 && (
              <p className="text-xs text-gray-500 mt-2">... and {emailsSent.length - 5} more emails sent</p>
            )}
          </div>
        )}

        {/* Quick Actions */}
        <div className="border-t pt-4">
          <p className="text-sm font-medium mb-2">Quick Actions:</p>
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectedRecipients(["employee"])
                setSelectedTemplate(processType === "onboarding" ? "welcome" : "exit_initiated")
              }}
            >
              <User className="h-3 w-3 mr-1" />
              Notify Employee
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectedRecipients(["hr"])
                setSelectedTemplate(processType === "onboarding" ? "hr_approval_needed" : "exit_complete")
              }}
            >
              <Users className="h-3 w-3 mr-1" />
              Update HR
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectedRecipients(["it"])
                setSelectedTemplate(processType === "onboarding" ? "software_installation" : "software_cleanup")
              }}
            >
              <Building className="h-3 w-3 mr-1" />
              Alert IT
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Mail, User, Users, Building, Clock, CheckCircle, Eye, EyeOff } from "lucide-react"
import { EmailTrackingService, type EmailRecord } from "@/lib/email-tracking-service"

interface EmailActivityProps {
  processType?: "onboarding" | "exit" | "employee_added"
  processId?: string
  limit?: number
  showAll?: boolean
}

export function EmailActivity({ processType, processId, limit = 10, showAll = false }: EmailActivityProps) {
  const [emails, setEmails] = useState<EmailRecord[]>([])
  const [expandedEmails, setExpandedEmails] = useState<Set<string>>(new Set())

  useEffect(() => {
    const loadEmails = () => {
      if (processType) {
        setEmails(EmailTrackingService.getByProcess(processType, processId))
      } else {
        setEmails(EmailTrackingService.getRecent(showAll ? 50 : limit))
      }
    }

    loadEmails()

    // Refresh every 2 seconds to show new emails
    const interval = setInterval(loadEmails, 2000)
    return () => clearInterval(interval)
  }, [processType, processId, limit, showAll])

  const getRecipientIcon = (type: string) => {
    switch (type) {
      case "employee":
        return <User className="h-4 w-4 text-blue-600" />
      case "hr":
        return <Users className="h-4 w-4 text-green-600" />
      case "it":
        return <Building className="h-4 w-4 text-purple-600" />
      case "manager":
        return <User className="h-4 w-4 text-orange-600" />
      default:
        return <Mail className="h-4 w-4 text-gray-600" />
    }
  }

  const getRecipientColor = (type: string) => {
    switch (type) {
      case "employee":
        return "bg-blue-100 text-blue-800"
      case "hr":
        return "bg-green-100 text-green-800"
      case "it":
        return "bg-purple-100 text-purple-800"
      case "manager":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getProcessColor = (type: string) => {
    switch (type) {
      case "onboarding":
        return "bg-blue-100 text-blue-800"
      case "exit":
        return "bg-red-100 text-red-800"
      case "employee_added":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const toggleEmailExpansion = (emailId: string) => {
    const newExpanded = new Set(expandedEmails)
    if (newExpanded.has(emailId)) {
      newExpanded.delete(emailId)
    } else {
      newExpanded.add(emailId)
    }
    setExpandedEmails(newExpanded)
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)

    if (diffMins < 1) return "Just now"
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return date.toLocaleDateString()
  }

  if (emails.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Mail className="h-5 w-5 mr-2 text-gray-400" />
            Email Activity
          </CardTitle>
          <CardDescription>No emails sent yet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <Mail className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>Email notifications will appear here when sent</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Mail className="h-5 w-5 mr-2 text-blue-600" />
            Email Activity
          </div>
          <Badge variant="outline">{emails.length} emails</Badge>
        </CardTitle>
        <CardDescription>
          {processType ? `Emails for ${processType} process` : "Recent email notifications"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-4">
            {emails.map((email) => (
              <div key={email.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getRecipientIcon(email.recipientType)}
                    <div>
                      <p className="font-medium text-sm">{email.subject}</p>
                      <p className="text-xs text-gray-500">To: {email.recipient}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getRecipientColor(email.recipientType)}>
                      {email.recipientType.toUpperCase()}
                    </Badge>
                    <Badge className={getProcessColor(email.processType)}>
                      {email.processType.replace("_", " ").toUpperCase()}
                    </Badge>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <Clock className="h-3 w-3" />
                    <span>{formatTime(email.timestamp)}</span>
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span className="text-green-600">Sent</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => toggleEmailExpansion(email.id)} className="h-6 px-2">
                    {expandedEmails.has(email.id) ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  </Button>
                </div>

                {expandedEmails.has(email.id) && (
                  <div className="mt-3 p-3 bg-gray-50 rounded border-l-4 border-blue-500">
                    <p className="text-sm font-medium mb-2">Email Content:</p>
                    <div className="text-sm text-gray-700 whitespace-pre-line">{email.content}</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

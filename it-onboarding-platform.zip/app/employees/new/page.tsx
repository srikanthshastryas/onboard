"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, UserPlus, Mail, Phone, Calendar, Building, User } from "lucide-react"
import Link from "next/link"
import { EmployeeService } from "@/lib/employee-service"
import { EmailTrackingService } from "@/lib/email-tracking-service"
import { EmailActivity } from "@/components/email-activity"

export default function NewEmployee() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    department: "",
    position: "",
    startDate: "",
    manager: "",
    workLocation: "",
    employmentType: "",
    salary: "",
    notes: "",
  })

  const departments = ["Engineering", "Marketing", "Sales", "Finance", "Human Resources", "Operations"]
  const managers = ["Sarah Johnson", "Michael Brown", "Lisa Davis", "Robert Taylor", "Jennifer Wilson", "David Miller"]
  const workLocations = ["Remote", "New York Office", "San Francisco Office", "London Office", "Hybrid"]
  const employmentTypes = ["Full-time", "Part-time", "Contract", "Intern"]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Generate employee ID if not provided
      const employeeId = formData.employeeId || EmployeeService.generateEmployeeId()

      // Create the employee record
      const newEmployee = EmployeeService.create({
        employeeId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        department: formData.department,
        position: formData.position,
        startDate: formData.startDate,
        manager: formData.manager,
        workLocation: formData.workLocation,
        employmentType: formData.employmentType,
        salary: formData.salary,
        notes: formData.notes,
        status: "pending_start", // New employees start as pending
      })

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Send notification emails
      EmailTrackingService.add({
        recipient: "hr@company.com",
        recipientType: "hr",
        subject: `New employee added - ${formData.firstName} ${formData.lastName}`,
        content: `New employee ${formData.firstName} ${formData.lastName} (${employeeId}) has been added to the system.
      
Department: ${formData.department}
Position: ${formData.position}
Start Date: ${formData.startDate}
Manager: ${formData.manager}
Email: ${formData.email}

The employee is now ready for onboarding process initiation.`,
        processType: "employee_added",
        processId: employeeId,
      })

      EmailTrackingService.add({
        recipient: "it@company.com",
        recipientType: "it",
        subject: `Prepare for new employee onboarding - ${formData.firstName} ${formData.lastName}`,
        content: `Please prepare for upcoming onboarding of ${formData.firstName} ${formData.lastName}.

Employee ID: ${employeeId}
Department: ${formData.department}
Start Date: ${formData.startDate}
Work Location: ${formData.workLocation}

Onboarding request will be initiated closer to start date.`,
        processType: "employee_added",
        processId: employeeId,
      })

      alert(`✅ Employee added successfully!

Employee ID: ${employeeId}
Name: ${formData.firstName} ${formData.lastName}
📧 Notifications sent to HR and IT teams

The employee is now in the system and ready for onboarding when their start date approaches.`)

      // Redirect to employees list
      setTimeout(() => {
        router.push("/employees")
      }, 2000)
    } catch (error) {
      console.error("Error adding employee:", error)
      alert("❌ Error adding employee. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-6">
            <Link href="/employees">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Employees
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Add New Employee</h1>
              <p className="text-gray-600">Create a new employee record in the system</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2 text-blue-600" />
                Personal Information
              </CardTitle>
              <CardDescription>Basic employee details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="employeeId">Employee ID</Label>
                  <Input
                    id="employeeId"
                    value={formData.employeeId}
                    onChange={(e) => setFormData((prev) => ({ ...prev, employeeId: e.target.value }))}
                    placeholder="Auto-generated if empty"
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave empty to auto-generate</p>
                </div>
                <div></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, firstName: e.target.value }))}
                    placeholder="John"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, lastName: e.target.value }))}
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email" className="flex items-center">
                    <Mail className="h-4 w-4 mr-1" />
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="john.doe@company.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Job Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="h-5 w-5 mr-2 text-green-600" />
                Job Information
              </CardTitle>
              <CardDescription>Role and department details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="department">Department *</Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, department: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((dept) => (
                        <SelectItem key={dept} value={dept}>
                          {dept}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="position">Position *</Label>
                  <Input
                    id="position"
                    value={formData.position}
                    onChange={(e) => setFormData((prev) => ({ ...prev, position: e.target.value }))}
                    placeholder="Software Engineer"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="manager">Manager</Label>
                  <Select
                    value={formData.manager}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, manager: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select manager" />
                    </SelectTrigger>
                    <SelectContent>
                      {managers.map((manager) => (
                        <SelectItem key={manager} value={manager}>
                          {manager}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="employmentType">Employment Type</Label>
                  <Select
                    value={formData.employmentType}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, employmentType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select employment type" />
                    </SelectTrigger>
                    <SelectContent>
                      {employmentTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startDate" className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Start Date *
                  </Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, startDate: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="workLocation">Work Location</Label>
                  <Select
                    value={formData.workLocation}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, workLocation: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select work location" />
                    </SelectTrigger>
                    <SelectContent>
                      {workLocations.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="salary">Annual Salary (Optional)</Label>
                <Input
                  id="salary"
                  value={formData.salary}
                  onChange={(e) => setFormData((prev) => ({ ...prev, salary: e.target.value }))}
                  placeholder="$75,000"
                />
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Information</CardTitle>
              <CardDescription>Any additional notes or special requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  placeholder="Any special requirements, accommodations, or additional information..."
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Email Activity Section */}
          <EmailActivity processType="employee_added" limit={5} />

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <Link href="/employees">
              <Button variant="outline" disabled={isSubmitting}>
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting}>
              <UserPlus className="h-4 w-4 mr-2" />
              {isSubmitting ? "Adding Employee..." : "Add Employee"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}

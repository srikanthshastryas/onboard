"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Edit, Package, DollarSign, Calendar, MapPin, User, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { AssetService, type Asset } from "@/lib/asset-service"

export default function AssetDetails({ params }: { params: { id: string } }) {
  const [asset, setAsset] = useState<Asset | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadAsset = () => {
      const assetData = AssetService.getById(Number.parseInt(params.id))
      setAsset(assetData)
      setLoading(false)
    }

    loadAsset()
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Loading asset details...</p>
        </div>
      </div>
    )
  }

  if (!asset) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <p className="text-gray-500 mb-4">Asset not found</p>
          <Link href="/assets">
            <Button>Back to Assets</Button>
          </Link>
        </div>
      </div>
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800"
      case "assigned":
        return "bg-blue-100 text-blue-800"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800"
      case "retired":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const isWarrantyExpiring = () => {
    if (!asset.warrantyExpiry) return false
    const expiryDate = new Date(asset.warrantyExpiry)
    const today = new Date()
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return daysUntilExpiry <= 90 && daysUntilExpiry > 0
  }

  const isWarrantyExpired = () => {
    if (!asset.warrantyExpiry) return false
    const expiryDate = new Date(asset.warrantyExpiry)
    const today = new Date()
    return expiryDate < today
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/assets">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Assets
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {asset.brand} {asset.model}
                </h1>
                <p className="text-gray-600">Serial: {asset.serialNumber}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className={getStatusColor(asset.status)}>{asset.status.toUpperCase()}</Badge>
              <Link href={`/assets/${asset.id}/edit`}>
                <Button variant="outline">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Asset Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2 text-blue-600" />
                  Asset Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Type</p>
                    <p className="text-lg">{asset.type}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Brand</p>
                    <p className="text-lg">{asset.brand}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Model</p>
                    <p className="text-lg">{asset.model}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Serial Number</p>
                    <p className="text-lg font-mono">{asset.serialNumber}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      Location
                    </p>
                    <p className="text-lg">{asset.location}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Status</p>
                    <Badge className={getStatusColor(asset.status)}>{asset.status.toUpperCase()}</Badge>
                  </div>
                </div>

                {asset.assignedTo && (
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      Assigned To
                    </p>
                    <p className="text-lg">
                      {asset.assignedTo} ({asset.assignedToId})
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Purchase Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                  Purchase Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Purchase Date
                    </p>
                    <p className="text-lg">
                      {asset.purchaseDate ? new Date(asset.purchaseDate).toLocaleDateString() : "Not specified"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Purchase Price</p>
                    <p className="text-lg">
                      {asset.purchasePrice ? `$${asset.purchasePrice.toLocaleString()}` : "Not specified"}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-500">Warranty Expiry</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-lg">
                      {asset.warrantyExpiry ? new Date(asset.warrantyExpiry).toLocaleDateString() : "Not specified"}
                    </p>
                    {isWarrantyExpired() && <Badge className="bg-red-100 text-red-800">Expired</Badge>}
                    {isWarrantyExpiring() && <Badge className="bg-yellow-100 text-yellow-800">Expiring Soon</Badge>}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notes */}
            {asset.notes && (
              <Card>
                <CardHeader>
                  <CardTitle>Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 whitespace-pre-line">{asset.notes}</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Actions Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Manage this asset</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href={`/assets/${asset.id}/edit`}>
                  <Button className="w-full">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Asset
                  </Button>
                </Link>

                {asset.status === "available" && (
                  <Button variant="outline" className="w-full bg-transparent">
                    <User className="h-4 w-4 mr-2" />
                    Assign to Employee
                  </Button>
                )}

                {asset.status === "assigned" && (
                  <Button variant="destructive" className="w-full">
                    Return Asset
                  </Button>
                )}

                <Button variant="outline" className="w-full bg-transparent">
                  <Package className="h-4 w-4 mr-2" />
                  View History
                </Button>
              </CardContent>
            </Card>

            {/* Warranty Alert */}
            {(isWarrantyExpiring() || isWarrantyExpired()) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-yellow-600">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Warranty Alert
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isWarrantyExpired() && (
                    <p className="text-red-700 text-sm">
                      ⚠️ Warranty has expired. Consider renewal or replacement planning.
                    </p>
                  )}
                  {isWarrantyExpiring() && (
                    <p className="text-yellow-700 text-sm">
                      ⚠️ Warranty expires within 90 days. Consider renewal options.
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* System Information */}
            <Card>
              <CardHeader>
                <CardTitle>System Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">Created</p>
                  <p className="text-sm">{new Date(asset.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Last Updated</p>
                  <p className="text-sm">{new Date(asset.lastUpdated).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Asset ID</p>
                  <p className="text-sm font-mono">#{asset.id}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

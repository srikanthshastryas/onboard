"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Plus, Eye, CheckCircle, Clock, AlertTriangle, Search } from "lucide-react"
import Link from "next/link"

export default function ExitList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const exitRequests = [
    {
      id: 1,
      employee: "Mike Johnson",
      employeeId: "EMP003",
      department: "Sales",
      exitDate: "2024-04-01",
      status: "completed",
      assetsReturned: true,
      softwareRevoked: true,
      dataDeleted: true,
      createdAt: "2024-03-15",
      progress: 100,
    },
    {
      id: 2,
      employee: "Sarah Wilson",
      employeeId: "EMP004",
      department: "Finance",
      exitDate: "2024-04-15",
      status: "in_progress",
      assetsReturned: true,
      softwareRevoked: false,
      dataDeleted: false,
      createdAt: "2024-03-20",
      progress: 60,
    },
    {
      id: 3,
      employee: "Tom Brown",
      employeeId: "EMP005",
      department: "Marketing",
      exitDate: "2024-05-01",
      status: "pending",
      assetsReturned: false,
      softwareRevoked: false,
      dataDeleted: false,
      createdAt: "2024-03-25",
      progress: 20,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4" />
      case "in_progress":
        return <Clock className="h-4 w-4" />
      case "pending":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const filteredRequests = exitRequests.filter((request) => {
    const matchesSearch =
      request.employee.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.employeeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.department.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || request.status === statusFilter

    return matchesSearch && matchesStatus
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Exit Requests</h1>
            </div>
            <Link href="/exit/new">
              <Button variant="destructive">
                <Plus className="h-4 w-4 mr-2" />
                New Exit Request
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Filters */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search by name, ID, or department..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={statusFilter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("all")}
            >
              All ({exitRequests.length})
            </Button>
            <Button
              variant={statusFilter === "pending" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("pending")}
            >
              Pending ({exitRequests.filter((r) => r.status === "pending").length})
            </Button>
            <Button
              variant={statusFilter === "in_progress" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("in_progress")}
            >
              In Progress ({exitRequests.filter((r) => r.status === "in_progress").length})
            </Button>
            <Button
              variant={statusFilter === "completed" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("completed")}
            >
              Completed ({exitRequests.filter((r) => r.status === "completed").length})
            </Button>
          </div>
        </div>

        {/* Requests List */}
        <div className="space-y-6">
          {filteredRequests.map((request) => (
            <Card key={request.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <span>{request.employee}</span>
                      <Badge variant="outline">{request.employeeId}</Badge>
                    </CardTitle>
                    <CardDescription>
                      {request.department} • Exit Date: {new Date(request.exitDate).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(request.status)}>
                      {getStatusIcon(request.status)}
                      <span className="ml-1 capitalize">{request.status.replace("_", " ")}</span>
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Exit Progress</span>
                    <span>{request.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-red-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${request.progress}%` }}
                    ></div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className={`h-4 w-4 ${request.assetsReturned ? "text-green-600" : "text-gray-400"}`} />
                    <span className="text-sm">Assets Returned</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle
                      className={`h-4 w-4 ${request.softwareRevoked ? "text-green-600" : "text-gray-400"}`}
                    />
                    <span className="text-sm">Software Revoked</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className={`h-4 w-4 ${request.dataDeleted ? "text-green-600" : "text-gray-400"}`} />
                    <span className="text-sm">Data Deleted</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-500">Created:</span>
                    <span className="text-sm">{new Date(request.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-end">
                    <Link href={`/exit/${request.id}`}>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Status Messages */}
                {request.status === "pending" && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-yellow-800 text-sm">
                      <AlertTriangle className="h-4 w-4 inline mr-1" />
                      Exit process initiated. Waiting for asset return and system cleanup to begin.
                    </p>
                  </div>
                )}

                {request.status === "in_progress" && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-blue-800 text-sm">
                      <Clock className="h-4 w-4 inline mr-1" />
                      {!request.assetsReturned ? "Assets pending return. " : ""}
                      {!request.softwareRevoked ? "Software licenses being revoked. " : ""}
                      {!request.dataDeleted ? "Data deletion in progress. " : ""}
                      Final system cleanup pending.
                    </p>
                  </div>
                )}

                {request.status === "completed" && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-green-800 text-sm">
                      <CheckCircle className="h-4 w-4 inline mr-1" />
                      Exit process completed successfully! All assets returned, software revoked, and data securely
                      deleted.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredRequests.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No exit requests found matching your criteria.</p>
            <Link href="/exit/new">
              <Button variant="destructive" className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                Create First Exit Request
              </Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Mail, Search, Filter, Download, Trash2, RefreshCw } from "lucide-react"
import Link from "next/link"
import { EmailActivity } from "@/components/email-activity"
import { EmailTrackingService, type EmailRecord } from "@/lib/email-tracking-service"

export default function EmailsPage() {
  const [emails, setEmails] = useState<EmailRecord[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [recipientFilter, setRecipientFilter] = useState("all")
  const [processFilter, setProcessFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  useEffect(() => {
    const loadEmails = () => {
      const allEmails = EmailTrackingService.getAll()
      setEmails(allEmails)
    }

    loadEmails()
    // Refresh every 5 seconds
    const interval = setInterval(loadEmails, 5000)
    return () => clearInterval(interval)
  }, [])

  const filteredEmails = emails.filter((email) => {
    const matchesSearch =
      email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.content.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesRecipient = recipientFilter === "all" || email.recipientType === recipientFilter
    const matchesProcess = processFilter === "all" || email.processType === processFilter
    const matchesStatus = statusFilter === "all" || email.status === statusFilter

    return matchesSearch && matchesRecipient && matchesProcess && matchesStatus
  })

  const stats = {
    total: emails.length,
    sent: emails.filter((e) => e.status === "sent").length,
    pending: emails.filter((e) => e.status === "pending").length,
    failed: emails.filter((e) => e.status === "failed").length,
    last24h: emails.filter((e) => new Date(e.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)).length,
    byRecipientType: {
      employee: emails.filter((e) => e.recipientType === "employee").length,
      hr: emails.filter((e) => e.recipientType === "hr").length,
      it: emails.filter((e) => e.recipientType === "it").length,
      manager: emails.filter((e) => e.recipientType === "manager").length,
    },
  }

  const exportEmails = () => {
    const csvContent = [
      "Timestamp,Recipient,Recipient Type,Subject,Process Type,Status",
      ...filteredEmails.map(
        (email) =>
          `${email.timestamp},${email.recipient},${email.recipientType},"${email.subject}",${email.processType},${email.status}`,
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `email-log-${new Date().toISOString().split("T")[0]}.csv`
    link.click()
    window.URL.revokeObjectURL(url)
  }

  const clearEmailLog = () => {
    if (confirm("Are you sure you want to clear all email logs? This action cannot be undone.")) {
      EmailTrackingService.clear()
      setEmails([])
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Email Management</h1>
                <p className="text-gray-600">Monitor and manage system email notifications</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={exportEmails}>
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              <Button variant="outline" onClick={() => window.location.reload()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="destructive" onClick={clearEmailLog}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear Log
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="activity">Email Activity</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Emails</CardTitle>
                  <Mail className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.total}</div>
                  <p className="text-xs text-muted-foreground">All time</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sent Successfully</CardTitle>
                  <div className="h-4 w-4 bg-green-500 rounded-full" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{stats.sent}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.total > 0 ? Math.round((stats.sent / stats.total) * 100) : 0}% success rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Last 24 Hours</CardTitle>
                  <div className="h-4 w-4 bg-blue-500 rounded-full" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{stats.last24h}</div>
                  <p className="text-xs text-muted-foreground">Recent activity</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Failed/Pending</CardTitle>
                  <div className="h-4 w-4 bg-red-500 rounded-full" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">{stats.failed + stats.pending}</div>
                  <p className="text-xs text-muted-foreground">Needs attention</p>
                </CardContent>
              </Card>
            </div>

            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Email Filters
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search emails..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  <Select value={recipientFilter} onValueChange={setRecipientFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Recipient Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Recipients</SelectItem>
                      <SelectItem value="employee">Employees</SelectItem>
                      <SelectItem value="hr">HR Team</SelectItem>
                      <SelectItem value="it">IT Team</SelectItem>
                      <SelectItem value="manager">Managers</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={processFilter} onValueChange={setProcessFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Process Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Processes</SelectItem>
                      <SelectItem value="onboarding">Onboarding</SelectItem>
                      <SelectItem value="exit">Exit</SelectItem>
                      <SelectItem value="employee_added">Employee Added</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Email List */}
            <Card>
              <CardHeader>
                <CardTitle>Email Log ({filteredEmails.length} emails)</CardTitle>
                <CardDescription>Filtered email notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {filteredEmails.map((email) => (
                    <div key={email.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{email.recipientType.toUpperCase()}</Badge>
                          <Badge variant="outline">{email.processType.replace("_", " ").toUpperCase()}</Badge>
                          <Badge
                            className={
                              email.status === "sent"
                                ? "bg-green-100 text-green-800"
                                : email.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                            }
                          >
                            {email.status.toUpperCase()}
                          </Badge>
                        </div>
                        <span className="text-sm text-gray-500">{new Date(email.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="font-medium">{email.subject}</p>
                      <p className="text-sm text-gray-600">To: {email.recipient}</p>
                    </div>
                  ))}

                  {filteredEmails.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Mail className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No emails found matching your filters</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity">
            <EmailActivity showAll={true} />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Emails by Recipient Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Employees</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{
                              width: `${stats.total > 0 ? (stats.byRecipientType.employee / stats.total) * 100 : 0}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium">{stats.byRecipientType.employee}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>HR Team</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full"
                            style={{
                              width: `${stats.total > 0 ? (stats.byRecipientType.hr / stats.total) * 100 : 0}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium">{stats.byRecipientType.hr}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>IT Team</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{
                              width: `${stats.total > 0 ? (stats.byRecipientType.it / stats.total) * 100 : 0}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium">{stats.byRecipientType.it}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Managers</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-orange-600 h-2 rounded-full"
                            style={{
                              width: `${stats.total > 0 ? (stats.byRecipientType.manager / stats.total) * 100 : 0}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium">{stats.byRecipientType.manager}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Email Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-3xl font-bold text-green-600">
                        {stats.total > 0 ? Math.round((stats.sent / stats.total) * 100) : 0}%
                      </p>
                      <p className="text-sm text-green-800">Success Rate</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <p className="text-xl font-bold text-blue-600">{stats.sent}</p>
                        <p className="text-xs text-blue-800">Sent</p>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <p className="text-xl font-bold text-red-600">{stats.failed}</p>
                        <p className="text-xs text-red-800">Failed</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

// Email tracking service with database integration
import { DatabaseService } from "./database-service"

export interface EmailRecord {
  id: number
  recipient_email: string
  recipient_type: "employee" | "hr" | "it" | "manager"
  subject: string
  content: string
  process_type: "onboarding" | "exit" | "employee_added" | "asset_assigned"
  process_id?: number
  status: "sent" | "pending" | "failed"
  sent_at: string
  created_at: string
}

export class EmailTrackingService {
  static async getAll(): Promise<EmailRecord[]> {
    try {
      return await DatabaseService.findAll("email_logs", "TRUE ORDER BY sent_at DESC")
    } catch (error) {
      console.error("Error fetching email logs:", error)
      return []
    }
  }

  static async add(email: Omit<EmailRecord, "id" | "sent_at" | "created_at" | "status">): Promise<EmailRecord> {
    try {
      const newEmail = await DatabaseService.create("email_logs", {
        recipient_email: email.recipient_email,
        recipient_type: email.recipient_type,
        subject: email.subject,
        content: email.content,
        process_type: email.process_type,
        process_id: email.process_id,
        status: "sent",
        sent_at: new Date().toISOString(),
      })

      return newEmail
    } catch (error) {
      console.error("Error adding email log:", error)
      throw error
    }
  }

  static async getByProcess(processType: string, processId?: number): Promise<EmailRecord[]> {
    try {
      if (processId) {
        return await DatabaseService.findAll(
          "email_logs",
          "process_type = $1 AND process_id = $2 ORDER BY sent_at DESC",
          [processType, processId],
        )
      } else {
        return await DatabaseService.findAll("email_logs", "process_type = $1 ORDER BY sent_at DESC", [processType])
      }
    } catch (error) {
      console.error("Error fetching emails by process:", error)
      return []
    }
  }

  static async getRecent(limit = 10): Promise<EmailRecord[]> {
    try {
      const emails = await DatabaseService.findAll("email_logs", "TRUE ORDER BY sent_at DESC")
      return emails.slice(0, limit)
    } catch (error) {
      console.error("Error fetching recent emails:", error)
      return []
    }
  }

  static async updateStatus(id: number, status: "sent" | "pending" | "failed"): Promise<EmailRecord | null> {
    try {
      return await DatabaseService.update("email_logs", id, { status })
    } catch (error) {
      console.error("Error updating email status:", error)
      return null
    }
  }

  static async clear(): Promise<void> {
    try {
      await DatabaseService.getConnection().then((db) => db.execute("DELETE FROM email_logs"))
    } catch (error) {
      console.error("Error clearing email logs:", error)
    }
  }

  // Email statistics
  static async getEmailStats(): Promise<{
    total: number
    sent: number
    pending: number
    failed: number
    last24h: number
    last7Days: number
    byRecipientType: Record<string, number>
    byProcessType: Record<string, number>
    byStatus: Record<string, number>
  }> {
    try {
      const emails = await this.getAll()
      const now = new Date()
      const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

      const stats = {
        total: emails.length,
        sent: emails.filter((e) => e.status === "sent").length,
        pending: emails.filter((e) => e.status === "pending").length,
        failed: emails.filter((e) => e.status === "failed").length,
        last24h: emails.filter((e) => new Date(e.sent_at) > last24h).length,
        last7Days: emails.filter((e) => new Date(e.sent_at) > last7Days).length,
        byRecipientType: {} as Record<string, number>,
        byProcessType: {} as Record<string, number>,
        byStatus: {} as Record<string, number>,
      }

      // Group by recipient type, process type, status
      emails.forEach((email) => {
        stats.byRecipientType[email.recipient_type] = (stats.byRecipientType[email.recipient_type] || 0) + 1
        stats.byProcessType[email.process_type] = (stats.byProcessType[email.process_type] || 0) + 1
        stats.byStatus[email.status] = (stats.byStatus[email.status] || 0) + 1
      })

      return stats
    } catch (error) {
      console.error("Error generating email stats:", error)
      return {
        total: 0,
        sent: 0,
        pending: 0,
        failed: 0,
        last24h: 0,
        last7Days: 0,
        byRecipientType: {},
        byProcessType: {},
        byStatus: {},
      }
    }
  }
}

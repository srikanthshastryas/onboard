// Database service for handling database operations
// This would typically use a real database connection in production

export interface DatabaseConnection {
  query: (sql: string, params?: any[]) => Promise<any[]>
  queryOne: (sql: string, params?: any[]) => Promise<any>
  execute: (sql: string, params?: any[]) => Promise<void>
}

// Mock database implementation for demo purposes
// In production, this would use a real database like PostgreSQL
class MockDatabase implements DatabaseConnection {
  private data: { [table: string]: any[] } = {
    departments: [],
    employees: [],
    assets: [],
    software_licenses: [],
    onboarding_requests: [],
    exit_requests: [],
    asset_assignments: [],
    software_assignments: [],
    email_logs: [],
    system_settings: [],
  }

  private nextId = 1

  async query(sql: string, params: any[] = []): Promise<any[]> {
    // This is a simplified mock implementation
    // In production, this would execute actual SQL queries
    console.log("Executing SQL:", sql, "with params:", params)

    // Parse basic SQL operations for demo
    const sqlLower = sql.toLowerCase().trim()

    if (sqlLower.startsWith("select")) {
      return this.handleSelect(sql, params)
    } else if (sqlLower.startsWith("insert")) {
      return this.handleInsert(sql, params)
    } else if (sqlLower.startsWith("update")) {
      return this.handleUpdate(sql, params)
    } else if (sqlLower.startsWith("delete")) {
      return this.handleDelete(sql, params)
    }

    return []
  }

  async queryOne(sql: string, params: any[] = []): Promise<any> {
    const results = await this.query(sql, params)
    return results[0] || null
  }

  async execute(sql: string, params: any[] = []): Promise<void> {
    await this.query(sql, params)
  }

  private handleSelect(sql: string, params: any[]): any[] {
    // Extract table name from SQL
    const tableMatch = sql.match(/from\s+(\w+)/i)
    if (!tableMatch) return []

    const tableName = tableMatch[1]
    return this.data[tableName] || []
  }

  private handleInsert(sql: string, params: any[]): any[] {
    // Extract table name
    const tableMatch = sql.match(/insert\s+into\s+(\w+)/i)
    if (!tableMatch) return []

    const tableName = tableMatch[1]
    if (!this.data[tableName]) this.data[tableName] = []

    // Create new record with auto-incrementing ID
    const newRecord = {
      id: this.nextId++,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...this.parseInsertValues(sql, params),
    }

    this.data[tableName].push(newRecord)
    return [newRecord]
  }

  private handleUpdate(sql: string, params: any[]): any[] {
    // Basic update implementation
    const tableMatch = sql.match(/update\s+(\w+)/i)
    if (!tableMatch) return []

    const tableName = tableMatch[1]
    if (!this.data[tableName]) return []

    // Update all records for simplicity (in real implementation, would parse WHERE clause)
    this.data[tableName].forEach((record) => {
      record.updated_at = new Date().toISOString()
    })

    return this.data[tableName]
  }

  private handleDelete(sql: string, params: any[]): any[] {
    const tableMatch = sql.match(/delete\s+from\s+(\w+)/i)
    if (!tableMatch) return []

    const tableName = tableMatch[1]
    const deleted = this.data[tableName] || []
    this.data[tableName] = []
    return deleted
  }

  private parseInsertValues(sql: string, params: any[]): any {
    // Simplified parsing - in production would use proper SQL parser
    return params.reduce((obj, param, index) => {
      obj[`field_${index}`] = param
      return obj
    }, {})
  }

  // Method to seed initial data
  async seedData(): Promise<void> {
    // Load initial data from localStorage if available
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("mockDatabase")
      if (stored) {
        this.data = JSON.parse(stored)
        return
      }
    }

    // Seed with initial data
    await this.seedDepartments()
    await this.seedEmployees()
    await this.seedAssets()
    await this.seedSoftwareLicenses()
    await this.seedOnboardingRequests()
    await this.seedEmailLogs()

    // Save to localStorage
    if (typeof window !== "undefined") {
      localStorage.setItem("mockDatabase", JSON.stringify(this.data))
    }
  }

  private async seedDepartments(): Promise<void> {
    this.data.departments = [
      {
        id: 1,
        name: "Engineering",
        description: "Software development and technical teams",
        manager_name: "Sarah Johnson",
        budget: 500000.0,
      },
      {
        id: 2,
        name: "Marketing",
        description: "Marketing and brand management",
        manager_name: "Michael Brown",
        budget: 200000.0,
      },
      {
        id: 3,
        name: "Sales",
        description: "Sales and business development",
        manager_name: "Lisa Davis",
        budget: 300000.0,
      },
      {
        id: 4,
        name: "Human Resources",
        description: "HR and people operations",
        manager_name: "Robert Taylor",
        budget: 150000.0,
      },
      {
        id: 5,
        name: "Finance",
        description: "Financial planning and accounting",
        manager_name: "Jennifer Wilson",
        budget: 180000.0,
      },
      {
        id: 6,
        name: "Operations",
        description: "Business operations and support",
        manager_name: "David Miller",
        budget: 250000.0,
      },
    ]
  }

  private async seedEmployees(): Promise<void> {
    this.data.employees = [
      {
        id: 1,
        employee_id: "EMP001",
        first_name: "John",
        last_name: "Doe",
        email: "john.doe@company.com",
        phone: "+1 (555) 123-4567",
        department_id: 1,
        position: "Software Engineer",
        start_date: "2024-03-01",
        status: "active",
        manager: "Sarah Johnson",
        work_location: "Hybrid",
        employment_type: "Full-time",
        salary: "$85,000",
        notes: "Experienced developer with React and Node.js expertise",
      },
      {
        id: 2,
        employee_id: "EMP002",
        first_name: "Jane",
        last_name: "Smith",
        email: "jane.smith@company.com",
        phone: "+1 (555) 234-5678",
        department_id: 2,
        position: "Marketing Manager",
        start_date: "2024-03-15",
        status: "active",
        manager: "Michael Brown",
        work_location: "Remote",
        employment_type: "Full-time",
        salary: "$75,000",
        notes: "Digital marketing specialist",
      },
      {
        id: 3,
        employee_id: "EMP003",
        first_name: "Mike",
        last_name: "Johnson",
        email: "mike.johnson@company.com",
        phone: "+1 (555) 345-6789",
        department_id: 3,
        position: "Sales Representative",
        start_date: "2024-04-01",
        status: "exited",
        manager: "Lisa Davis",
        work_location: "New York Office",
        employment_type: "Full-time",
        salary: "$65,000",
        notes: "B2B sales experience",
      },
    ]
  }

  private async seedAssets(): Promise<void> {
    this.data.assets = [
      {
        id: 1,
        asset_type: "Laptop",
        brand: "Dell",
        model: "XPS 13",
        serial_number: "DL001",
        status: "available",
        assigned_to_id: null,
        purchase_date: "2024-01-15",
        purchase_price: 1299.0,
        warranty_expiry: "2027-01-15",
        location: "IT Storage Room A",
        notes: "High-performance ultrabook",
      },
      {
        id: 2,
        asset_type: "Laptop",
        brand: "Apple",
        model: "MacBook Pro M3",
        serial_number: "MB001",
        status: "assigned",
        assigned_to_id: 1,
        purchase_date: "2024-02-20",
        purchase_price: 2499.0,
        warranty_expiry: "2027-02-20",
        location: "Assigned to Employee",
        notes: "High-performance laptop for development work",
      },
    ]
  }

  private async seedSoftwareLicenses(): Promise<void> {
    this.data.software_licenses = [
      {
        id: 1,
        software_name: "Microsoft Office 365",
        license_type: "subscription",
        total_licenses: 150,
        assigned_licenses: 127,
        cost_per_license: 12.5,
        renewal_date: "2024-12-31",
        vendor: "Microsoft",
      },
      {
        id: 2,
        software_name: "Adobe Acrobat Pro",
        license_type: "subscription",
        total_licenses: 50,
        assigned_licenses: 23,
        cost_per_license: 19.99,
        renewal_date: "2024-11-30",
        vendor: "Adobe",
      },
    ]
  }

  private async seedOnboardingRequests(): Promise<void> {
    this.data.onboarding_requests = [
      {
        id: 1,
        employee_id: 1,
        status: "completed",
        progress: 100,
        hr_approval: true,
        hr_approved_by: "Robert Taylor",
        hr_approval_date: "2024-02-16T10:30:00Z",
        assets_assigned: true,
        office_installation: true,
        adobe_reader: true,
        compression_tool: true,
        vpn_setup: true,
        email_accounts_created: true,
        system_access_granted: true,
        notes: "Completed successfully",
      },
    ]
  }

  private async seedEmailLogs(): Promise<void> {
    this.data.email_logs = [
      {
        id: 1,
        recipient_email: "john.doe@company.com",
        recipient_type: "employee",
        subject: "Welcome to the team! Your onboarding has started",
        content: "Dear John Doe, Welcome to our organization!...",
        process_type: "onboarding",
        process_id: 1,
        status: "sent",
        sent_at: "2024-02-15T08:00:00Z",
      },
    ]
  }
}

// Singleton database instance
let dbInstance: DatabaseConnection | null = null

export async function getDatabase(): Promise<DatabaseConnection> {
  if (!dbInstance) {
    dbInstance = new MockDatabase()
    await (dbInstance as MockDatabase).seedData()
  }
  return dbInstance
}

// Database query helpers
export class DatabaseService {
  private static db: DatabaseConnection | null = null

  static async getConnection(): Promise<DatabaseConnection> {
    if (!this.db) {
      this.db = await getDatabase()
    }
    return this.db
  }

  // Generic CRUD operations
  static async findAll(table: string, conditions?: string, params?: any[]): Promise<any[]> {
    const db = await this.getConnection()
    const sql = conditions ? `SELECT * FROM ${table} WHERE ${conditions}` : `SELECT * FROM ${table}`
    return await db.query(sql, params)
  }

  static async findById(table: string, id: number): Promise<any> {
    const db = await this.getConnection()
    return await db.queryOne(`SELECT * FROM ${table} WHERE id = $1`, [id])
  }

  static async create(table: string, data: any): Promise<any> {
    const db = await this.getConnection()
    const fields = Object.keys(data).join(", ")
    const placeholders = Object.keys(data)
      .map((_, i) => `$${i + 1}`)
      .join(", ")
    const values = Object.values(data)

    const sql = `INSERT INTO ${table} (${fields}) VALUES (${placeholders}) RETURNING *`
    const result = await db.query(sql, values)
    return result[0]
  }

  static async update(table: string, id: number, data: any): Promise<any> {
    const db = await this.getConnection()
    const updates = Object.keys(data)
      .map((key, i) => `${key} = $${i + 2}`)
      .join(", ")
    const values = [id, ...Object.values(data)]

    const sql = `UPDATE ${table} SET ${updates}, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *`
    const result = await db.query(sql, values)
    return result[0]
  }

  static async delete(table: string, id: number): Promise<void> {
    const db = await this.getConnection()
    await db.execute(`DELETE FROM ${table} WHERE id = $1`, [id])
  }

  // Specialized queries
  static async getEmployeeWithDepartment(employeeId: string): Promise<any> {
    const db = await this.getConnection()
    return await db.queryOne(
      `
      SELECT e.*, d.name as department_name 
      FROM employees e 
      LEFT JOIN departments d ON e.department_id = d.id 
      WHERE e.employee_id = $1
    `,
      [employeeId],
    )
  }

  static async getAssetWithAssignee(assetId: number): Promise<any> {
    const db = await this.getConnection()
    return await db.queryOne(
      `
      SELECT a.*, e.first_name, e.last_name, e.employee_id 
      FROM assets a 
      LEFT JOIN employees e ON a.assigned_to_id = e.id 
      WHERE a.id = $1
    `,
      [assetId],
    )
  }

  static async getOnboardingWithEmployee(onboardingId: number): Promise<any> {
    const db = await this.getConnection()
    return await db.queryOne(
      `
      SELECT o.*, e.first_name, e.last_name, e.employee_id, e.email, d.name as department_name
      FROM onboarding_requests o
      JOIN employees e ON o.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE o.id = $1
    `,
      [onboardingId],
    )
  }

  static async getExitWithEmployee(exitId: number): Promise<any> {
    const db = await this.getConnection()
    return await db.queryOne(
      `
      SELECT ex.*, e.first_name, e.last_name, e.employee_id, e.email, d.name as department_name
      FROM exit_requests ex
      JOIN employees e ON ex.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE ex.id = $1
    `,
      [exitId],
    )
  }
}

// Employee management service with database integration
import { DatabaseService } from "./database-service"

export interface Employee {
  id: number
  employee_id: string
  first_name: string
  last_name: string
  email: string
  phone: string
  department_id: number
  department_name?: string
  position: string
  start_date: string
  end_date?: string
  status: "active" | "pending_start" | "exited" | "inactive"
  manager: string
  work_location: string
  employment_type: string
  salary: string
  notes: string
  created_at: string
  updated_at: string
}

export interface Department {
  id: number
  name: string
  description: string
  manager_name: string
  budget: number
}

export class EmployeeService {
  static async getAll(): Promise<Employee[]> {
    try {
      const employees = await DatabaseService.findAll("employees")

      // Get department names
      const departments = await DatabaseService.findAll("departments")
      const departmentMap = departments.reduce(
        (map, dept) => {
          map[dept.id] = dept.name
          return map
        },
        {} as Record<number, string>,
      )

      return employees.map((emp) => ({
        ...emp,
        department_name: departmentMap[emp.department_id] || "Unknown",
      }))
    } catch (error) {
      console.error("Error fetching employees:", error)
      return []
    }
  }

  static async create(employeeData: Omit<Employee, "id" | "created_at" | "updated_at">): Promise<Employee> {
    try {
      const newEmployee = await DatabaseService.create("employees", {
        employee_id: employeeData.employee_id,
        first_name: employeeData.first_name,
        last_name: employeeData.last_name,
        email: employeeData.email,
        phone: employeeData.phone,
        department_id: employeeData.department_id,
        position: employeeData.position,
        start_date: employeeData.start_date,
        end_date: employeeData.end_date,
        status: employeeData.status || "pending_start",
        manager: employeeData.manager,
        work_location: employeeData.work_location,
        employment_type: employeeData.employment_type,
        salary: employeeData.salary,
        notes: employeeData.notes,
      })

      return newEmployee
    } catch (error) {
      console.error("Error creating employee:", error)
      throw error
    }
  }

  static async update(id: number, updates: Partial<Employee>): Promise<Employee | null> {
    try {
      const updatedEmployee = await DatabaseService.update("employees", id, updates)
      return updatedEmployee
    } catch (error) {
      console.error("Error updating employee:", error)
      return null
    }
  }

  static async getById(id: number): Promise<Employee | null> {
    try {
      const employee = await DatabaseService.findById("employees", id)
      if (!employee) return null

      // Get department name
      if (employee.department_id) {
        const department = await DatabaseService.findById("departments", employee.department_id)
        employee.department_name = department?.name || "Unknown"
      }

      return employee
    } catch (error) {
      console.error("Error fetching employee by ID:", error)
      return null
    }
  }

  static async getByEmployeeId(employeeId: string): Promise<Employee | null> {
    try {
      const employee = await DatabaseService.getEmployeeWithDepartment(employeeId)
      return employee
    } catch (error) {
      console.error("Error fetching employee by employee ID:", error)
      return null
    }
  }

  static async getActiveEmployees(): Promise<Employee[]> {
    try {
      const employees = await DatabaseService.findAll("employees", "status = $1", ["active"])
      return employees
    } catch (error) {
      console.error("Error fetching active employees:", error)
      return []
    }
  }

  static async getPendingEmployees(): Promise<Employee[]> {
    try {
      const employees = await DatabaseService.findAll("employees", "status = $1", ["pending_start"])
      return employees
    } catch (error) {
      console.error("Error fetching pending employees:", error)
      return []
    }
  }

  static async generateEmployeeId(): Promise<string> {
    try {
      const employees = await this.getAll()
      const existingIds = employees.map((emp) => emp.employee_id)
      let counter = 1

      while (existingIds.includes(`EMP${counter.toString().padStart(3, "0")}`)) {
        counter++
      }

      return `EMP${counter.toString().padStart(3, "0")}`
    } catch (error) {
      console.error("Error generating employee ID:", error)
      return `EMP${Date.now().toString().slice(-3)}`
    }
  }

  // Department management
  static async getAllDepartments(): Promise<Department[]> {
    try {
      return await DatabaseService.findAll("departments")
    } catch (error) {
      console.error("Error fetching departments:", error)
      return []
    }
  }

  static async getDepartmentById(id: number): Promise<Department | null> {
    try {
      return await DatabaseService.findById("departments", id)
    } catch (error) {
      console.error("Error fetching department:", error)
      return null
    }
  }

  static async createDepartment(departmentData: Omit<Department, "id">): Promise<Department> {
    try {
      return await DatabaseService.create("departments", departmentData)
    } catch (error) {
      console.error("Error creating department:", error)
      throw error
    }
  }

  // Statistics and reporting
  static async getEmployeeStats(): Promise<{
    total: number
    active: number
    pending: number
    exited: number
    byDepartment: Record<string, number>
    byStatus: Record<string, number>
  }> {
    try {
      const employees = await this.getAll()

      const stats = {
        total: employees.length,
        active: employees.filter((e) => e.status === "active").length,
        pending: employees.filter((e) => e.status === "pending_start").length,
        exited: employees.filter((e) => e.status === "exited").length,
        byDepartment: {} as Record<string, number>,
        byStatus: {} as Record<string, number>,
      }

      // Group by department
      employees.forEach((emp) => {
        const dept = emp.department_name || "Unknown"
        stats.byDepartment[dept] = (stats.byDepartment[dept] || 0) + 1
      })

      // Group by status
      employees.forEach((emp) => {
        stats.byStatus[emp.status] = (stats.byStatus[emp.status] || 0) + 1
      })

      return stats
    } catch (error) {
      console.error("Error generating employee stats:", error)
      return {
        total: 0,
        active: 0,
        pending: 0,
        exited: 0,
        byDepartment: {},
        byStatus: {},
      }
    }
  }
}

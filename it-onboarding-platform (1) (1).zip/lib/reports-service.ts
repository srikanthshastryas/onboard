// Reports service for generating various reports with database integration
import { EmployeeService } from "./employee-service"
import { AssetService } from "./asset-service"
import { OnboardingService } from "./onboarding-service"
import { ExitService } from "./exit-service"
import { EmailTrackingService } from "./email-tracking-service"

export interface ReportData {
  id: string
  title: string
  description: string
  generatedAt: string
  data: any
  type: "employee" | "asset" | "onboarding" | "exit" | "email" | "financial"
}

export class ReportsService {
  static async generateEmployeeReport(): Promise<ReportData> {
    const stats = await EmployeeService.getEmployeeStats()
    const employees = await EmployeeService.getAll()
    const recentHires = employees
      .filter((e) => new Date(e.start_date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .sort((a, b) => new Date(b.start_date).getTime() - new Date(a.start_date).getTime())

    return {
      id: `employee-${Date.now()}`,
      title: "Employee Report",
      description: "Complete overview of all employees and their status",
      generatedAt: new Date().toISOString(),
      type: "employee",
      data: { employees, stats: { ...stats, recentHires } },
    }
  }

  static async generateAssetReport(): Promise<ReportData> {
    const stats = await AssetService.getAssetStats()
    const assets = await AssetService.getAll()

    return {
      id: `asset-${Date.now()}`,
      title: "Asset Inventory Report",
      description: "Complete asset inventory with financial summary",
      generatedAt: new Date().toISOString(),
      type: "asset",
      data: { assets, stats },
    }
  }

  static async generateOnboardingReport(): Promise<ReportData> {
    const stats = await OnboardingService.getOnboardingStats()
    const onboardingRequests = await OnboardingService.getAll()

    return {
      id: `onboarding-${Date.now()}`,
      title: "Onboarding Report",
      description: "Employee onboarding progress and statistics",
      generatedAt: new Date().toISOString(),
      type: "onboarding",
      data: { onboardingRequests, stats },
    }
  }

  static async generateExitReport(): Promise<ReportData> {
    const stats = await ExitService.getExitStats()
    const exitRequests = await ExitService.getAll()

    return {
      id: `exit-${Date.now()}`,
      title: "Exit Report",
      description: "Employee exit process and statistics",
      generatedAt: new Date().toISOString(),
      type: "exit",
      data: { exitRequests, stats },
    }
  }

  static async generateEmailReport(): Promise<ReportData> {
    const stats = await EmailTrackingService.getEmailStats()
    const emails = await EmailTrackingService.getRecent(50)

    return {
      id: `email-${Date.now()}`,
      title: "Email Activity Report",
      description: "System email notifications and communication log",
      generatedAt: new Date().toISOString(),
      type: "email",
      data: { emails, stats },
    }
  }

  static async generateFinancialReport(): Promise<ReportData> {
    const assetStats = await AssetService.getAssetStats()
    const employeeStats = await EmployeeService.getEmployeeStats()
    const assets = await AssetService.getAll()

    const expensiveAssets = assets
      .filter((a) => (a.purchase_price || 0) > 1000)
      .sort((a, b) => (b.purchase_price || 0) - (a.purchase_price || 0))

    const stats = {
      totalAssetValue: assetStats.totalValue,
      averageAssetValue: assetStats.averageValue,
      totalAssets: assetStats.total,
      totalEmployees: employeeStats.total,
      assetValuePerEmployee: employeeStats.total > 0 ? assetStats.totalValue / employeeStats.total : 0,
      expensiveAssets,
      assetsByValue: {
        under500: assets.filter((a) => (a.purchase_price || 0) < 500).length,
        between500and1000: assets.filter((a) => (a.purchase_price || 0) >= 500 && (a.purchase_price || 0) < 1000)
          .length,
        between1000and2000: assets.filter((a) => (a.purchase_price || 0) >= 1000 && (a.purchase_price || 0) < 2000)
          .length,
        over2000: assets.filter((a) => (a.purchase_price || 0) >= 2000).length,
      },
      monthlyDepreciation: assetStats.totalValue * 0.02, // Assuming 2% monthly depreciation
    }

    return {
      id: `financial-${Date.now()}`,
      title: "Financial Report",
      description: "Asset valuation and financial overview",
      generatedAt: new Date().toISOString(),
      type: "financial",
      data: { stats },
    }
  }

  static exportToCSV(data: any[], filename: string): void {
    if (data.length === 0) return

    const headers = Object.keys(data[0])
    const csvContent = [
      headers.join(","),
      ...data.map((row) =>
        headers
          .map((header) => {
            const value = row[header]
            return typeof value === "string" && value.includes(",") ? `"${value}"` : value
          })
          .join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `${filename}-${new Date().toISOString().split("T")[0]}.csv`
    link.click()
    window.URL.revokeObjectURL(url)
  }
}

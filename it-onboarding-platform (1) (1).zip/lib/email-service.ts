// Email service for sending notifications
export interface EmailNotification {
  to: string
  subject: string
  content: string
  type: "onboarding" | "exit"
  recipientType: "candidate" | "hr" | "it"
}

export class EmailService {
  static async sendOnboardingNotification(
    employeeName: string,
    employeeEmail: string,
    department: string,
    startDate: string,
  ) {
    const notifications: EmailNotification[] = [
      {
        to: employeeEmail,
        subject: `Welcome to the team! Your onboarding process has started`,
        content: `Dear ${employeeName},\n\nWelcome to our organization! Your onboarding process has been initiated for your start date of ${startDate}.\n\nYou will receive updates as we prepare your workspace and accounts.\n\nBest regards,\nIT Team`,
        type: "onboarding",
        recipientType: "candidate",
      },
      {
        to: "hr@company.com",
        subject: `New onboarding request for ${employeeName}`,
        content: `A new onboarding request has been created for ${employeeName} in the ${department} department.\n\nStart Date: ${startDate}\nEmployee Email: ${employeeEmail}\n\nPlease review and approve the request.`,
        type: "onboarding",
        recipientType: "hr",
      },
      {
        to: "it@company.com",
        subject: `Asset assignment required for ${employeeName}`,
        content: `Please prepare assets and accounts for new employee ${employeeName}.\n\nDepartment: ${department}\nStart Date: ${startDate}\n\nAssets and accounts should be ready by the start date.`,
        type: "onboarding",
        recipientType: "it",
      },
    ]

    // In a real application, you would send these emails using a service like SendGrid, AWS SES, etc.
    console.log("Sending onboarding notifications:", notifications)
    return notifications
  }

  static async sendExitNotification(employeeName: string, employeeEmail: string, exitDate: string) {
    const notifications: EmailNotification[] = [
      {
        to: employeeEmail,
        subject: `Exit process initiated - Important information`,
        content: `Dear ${employeeName},\n\nYour exit process has been initiated for ${exitDate}.\n\nPlease ensure all company assets are returned and coordinate with IT for data backup if needed.\n\nThank you for your service.\n\nBest regards,\nHR Team`,
        type: "exit",
        recipientType: "candidate",
      },
      {
        to: "hr@company.com",
        subject: `Exit process started for ${employeeName}`,
        content: `Exit process has been initiated for ${employeeName}.\n\nExit Date: ${exitDate}\n\nPlease coordinate final paperwork and benefits processing.`,
        type: "exit",
        recipientType: "hr",
      },
      {
        to: "it@company.com",
        subject: `Asset recovery and system cleanup required for ${employeeName}`,
        content: `Please initiate asset recovery and system cleanup for ${employeeName}.\n\nExit Date: ${exitDate}\n\nTasks:\n- Collect all assigned assets\n- Disable system accounts\n- Secure data deletion\n- Format devices`,
        type: "exit",
        recipientType: "it",
      },
    ]

    console.log("Sending exit notifications:", notifications)
    return notifications
  }

  static async sendSoftwareInstallationNotification(
    employeeName: string,
    department: string,
    softwareStatus: {
      office: boolean
      adobe: boolean
      compression: boolean
      vpn: boolean
    },
  ) {
    const pendingSoftware = []
    if (!softwareStatus.office) pendingSoftware.push("Microsoft Office Suite")
    if (!softwareStatus.adobe) pendingSoftware.push("Adobe Reader")
    if (!softwareStatus.compression) pendingSoftware.push("WinRAR/7-Zip")
    if (!softwareStatus.vpn) pendingSoftware.push("VPN Client")

    const notification: EmailNotification = {
      to: "it@company.com",
      subject: `Software installation required for ${employeeName}`,
      content:
        `Software installation checklist for new employee ${employeeName} (${department}):\n\n` +
        `Required Software:\n` +
        `✓ Microsoft Office Suite ${softwareStatus.office ? "(Completed)" : "(Pending)"}\n` +
        `✓ Adobe Reader DC ${softwareStatus.adobe ? "(Completed)" : "(Pending)"}\n` +
        `✓ Compression Tool (WinRAR/7-Zip) ${softwareStatus.compression ? "(Completed)" : "(Pending)"}\n` +
        `✓ VPN Client Setup ${softwareStatus.vpn ? "(Completed)" : "(Pending)"}\n\n` +
        (pendingSoftware.length > 0
          ? `Pending installations: ${pendingSoftware.join(", ")}\n\n`
          : `All software installations completed!\n\n`) +
        `Please ensure all software is installed and configured before the employee's start date.\n\n` +
        `Best regards,\nIT Onboarding System`,
      type: "onboarding",
      recipientType: "it",
    }

    console.log("Sending software installation notification:", notification)
    return [notification]
  }

  static async sendSoftwareCleanupNotification(
    employeeName: string,
    exitDate: string,
    cleanupStatus: {
      office: boolean
      adobe: boolean
      vpn: boolean
    },
  ) {
    const pendingCleanup = []
    if (!cleanupStatus.office) pendingCleanup.push("Microsoft Office license")
    if (!cleanupStatus.adobe) pendingCleanup.push("Adobe licenses")
    if (!cleanupStatus.vpn) pendingCleanup.push("VPN access")

    const notification: EmailNotification = {
      to: "it@company.com",
      subject: `Software cleanup required for ${employeeName} - Exit ${exitDate}`,
      content:
        `Software license and access cleanup for departing employee ${employeeName}:\n\n` +
        `Cleanup Checklist:\n` +
        `✓ Microsoft Office License ${cleanupStatus.office ? "(Revoked)" : "(Pending)"}\n` +
        `✓ Adobe Licenses ${cleanupStatus.adobe ? "(Deactivated)" : "(Pending)"}\n` +
        `✓ VPN Access ${cleanupStatus.vpn ? "(Revoked)" : "(Pending)"}\n\n` +
        (pendingCleanup.length > 0
          ? `Pending cleanup: ${pendingCleanup.join(", ")}\n\n`
          : `All software cleanup completed!\n\n`) +
        `Please ensure all licenses are properly revoked and reassigned to the available pool.\n\n` +
        `Exit Date: ${exitDate}\n\n` +
        `Best regards,\nIT Exit Management System`,
      type: "exit",
      recipientType: "it",
    }

    console.log("Sending software cleanup notification:", notification)
    return [notification]
  }

  static async sendStageUpdateNotification(
    employeeName: string,
    stage: string,
    status: "completed" | "pending",
    recipientEmails: string[],
  ) {
    const notifications: EmailNotification[] = recipientEmails.map((email) => ({
      to: email,
      subject: `${employeeName} - ${stage} ${status}`,
      content:
        `Update on ${employeeName}'s ${stage.toLowerCase()} process:\n\n` +
        `Status: ${status.toUpperCase()}\n` +
        `Stage: ${stage}\n` +
        `Timestamp: ${new Date().toLocaleString()}\n\n` +
        (status === "completed" ? `This stage has been completed successfully.` : `This stage is pending completion.`) +
        `\n\nNext steps will be communicated shortly.\n\n` +
        `Best regards,\nIT Management System`,
      type: stage.includes("exit") ? "exit" : "onboarding",
      recipientType: email.includes("hr") ? "hr" : email.includes("it") ? "it" : "candidate",
    }))

    console.log("Sending stage update notifications:", notifications)
    return notifications
  }
}

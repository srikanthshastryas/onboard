// Asset management service with database integration
import { DatabaseService } from "./database-service"

export interface Asset {
  id: number
  asset_type: string
  brand: string
  model: string
  serial_number: string
  status: "available" | "assigned" | "maintenance" | "retired"
  assigned_to_id?: number
  assigned_to_name?: string
  assigned_to_employee_id?: string
  image_url?: string
  purchase_date?: string
  purchase_price?: number
  warranty_expiry?: string
  location?: string
  notes?: string
  created_at: string
  updated_at: string
}

export interface AssetAssignment {
  id: number
  asset_id: number
  employee_id: number
  assigned_date: string
  returned_date?: string
  status: "active" | "returned"
  notes?: string
}

export class AssetService {
  static async getAll(): Promise<Asset[]> {
    try {
      const assets = await DatabaseService.findAll("assets")

      // Get assigned employee names
      for (const asset of assets) {
        if (asset.assigned_to_id) {
          const employee = await DatabaseService.findById("employees", asset.assigned_to_id)
          if (employee) {
            asset.assigned_to_name = `${employee.first_name} ${employee.last_name}`
            asset.assigned_to_employee_id = employee.employee_id
          }
        }
      }

      return assets
    } catch (error) {
      console.error("Error fetching assets:", error)
      return []
    }
  }

  static async create(assetData: Omit<Asset, "id" | "created_at" | "updated_at">): Promise<Asset> {
    try {
      const newAsset = await DatabaseService.create("assets", {
        asset_type: assetData.asset_type,
        brand: assetData.brand,
        model: assetData.model,
        serial_number: assetData.serial_number,
        status: assetData.status || "available",
        assigned_to_id: assetData.assigned_to_id,
        image_url: assetData.image_url,
        purchase_date: assetData.purchase_date,
        purchase_price: assetData.purchase_price,
        warranty_expiry: assetData.warranty_expiry,
        location: assetData.location,
        notes: assetData.notes,
      })

      return newAsset
    } catch (error) {
      console.error("Error creating asset:", error)
      throw error
    }
  }

  static async update(id: number, updates: Partial<Asset>): Promise<Asset | null> {
    try {
      const updatedAsset = await DatabaseService.update("assets", id, updates)
      return updatedAsset
    } catch (error) {
      console.error("Error updating asset:", error)
      return null
    }
  }

  static async getById(id: number): Promise<Asset | null> {
    try {
      const asset = await DatabaseService.getAssetWithAssignee(id)
      if (asset && asset.first_name) {
        asset.assigned_to_name = `${asset.first_name} ${asset.last_name}`
        asset.assigned_to_employee_id = asset.employee_id
      }
      return asset
    } catch (error) {
      console.error("Error fetching asset by ID:", error)
      return null
    }
  }

  static async getBySerialNumber(serialNumber: string): Promise<Asset | null> {
    try {
      const assets = await DatabaseService.findAll("assets", "serial_number = $1", [serialNumber])
      return assets[0] || null
    } catch (error) {
      console.error("Error fetching asset by serial number:", error)
      return null
    }
  }

  static async getAvailable(): Promise<Asset[]> {
    try {
      return await DatabaseService.findAll("assets", "status = $1", ["available"])
    } catch (error) {
      console.error("Error fetching available assets:", error)
      return []
    }
  }

  static async getAssigned(): Promise<Asset[]> {
    try {
      return await DatabaseService.findAll("assets", "status = $1", ["assigned"])
    } catch (error) {
      console.error("Error fetching assigned assets:", error)
      return []
    }
  }

  static async getByEmployee(employeeId: number): Promise<Asset[]> {
    try {
      return await DatabaseService.findAll("assets", "assigned_to_id = $1", [employeeId])
    } catch (error) {
      console.error("Error fetching assets by employee:", error)
      return []
    }
  }

  static async assignToEmployee(assetId: number, employeeId: number): Promise<boolean> {
    try {
      // Update asset status and assignment
      await DatabaseService.update("assets", assetId, {
        status: "assigned",
        assigned_to_id: employeeId,
        location: "Assigned to Employee",
      })

      // Create assignment record
      await DatabaseService.create("asset_assignments", {
        asset_id: assetId,
        employee_id: employeeId,
        status: "active",
        notes: "Asset assigned via system",
      })

      return true
    } catch (error) {
      console.error("Error assigning asset to employee:", error)
      return false
    }
  }

  static async returnFromEmployee(assetId: number, returnLocation = "IT Storage Room A"): Promise<boolean> {
    try {
      const asset = await this.getById(assetId)
      if (!asset || asset.status !== "assigned") return false

      // Update asset status
      await DatabaseService.update("assets", assetId, {
        status: "available",
        assigned_to_id: null,
        location: returnLocation,
      })

      // Update assignment record
      const assignments = await DatabaseService.findAll("asset_assignments", "asset_id = $1 AND status = $2", [
        assetId,
        "active",
      ])

      if (assignments.length > 0) {
        await DatabaseService.update("asset_assignments", assignments[0].id, {
          status: "returned",
          returned_date: new Date().toISOString(),
        })
      }

      return true
    } catch (error) {
      console.error("Error returning asset from employee:", error)
      return false
    }
  }

  static async generateSerialNumber(type: string, brand: string): Promise<string> {
    try {
      const assets = await this.getAll()
      const prefix = brand.substring(0, 2).toUpperCase()
      let counter = 1

      while (assets.some((asset) => asset.serial_number === `${prefix}${counter.toString().padStart(3, "0")}`)) {
        counter++
      }

      return `${prefix}${counter.toString().padStart(3, "0")}`
    } catch (error) {
      console.error("Error generating serial number:", error)
      return `${brand.substring(0, 2).toUpperCase()}${Date.now().toString().slice(-3)}`
    }
  }

  // Asset statistics and reporting
  static async getAssetStats(): Promise<{
    total: number
    available: number
    assigned: number
    maintenance: number
    retired: number
    totalValue: number
    averageValue: number
    byType: Record<string, number>
    byStatus: Record<string, number>
    byBrand: Record<string, number>
    expiringWarranties: Asset[]
    expiredWarranties: Asset[]
  }> {
    try {
      const assets = await this.getAll()
      const totalValue = assets.reduce((sum, asset) => sum + (asset.purchase_price || 0), 0)

      const stats = {
        total: assets.length,
        available: assets.filter((a) => a.status === "available").length,
        assigned: assets.filter((a) => a.status === "assigned").length,
        maintenance: assets.filter((a) => a.status === "maintenance").length,
        retired: assets.filter((a) => a.status === "retired").length,
        totalValue,
        averageValue: assets.length > 0 ? totalValue / assets.length : 0,
        byType: {} as Record<string, number>,
        byStatus: {} as Record<string, number>,
        byBrand: {} as Record<string, number>,
        expiringWarranties: [] as Asset[],
        expiredWarranties: [] as Asset[],
      }

      // Group by type, status, brand
      assets.forEach((asset) => {
        stats.byType[asset.asset_type] = (stats.byType[asset.asset_type] || 0) + 1
        stats.byStatus[asset.status] = (stats.byStatus[asset.status] || 0) + 1
        stats.byBrand[asset.brand] = (stats.byBrand[asset.brand] || 0) + 1

        // Check warranty status
        if (asset.warranty_expiry) {
          const expiryDate = new Date(asset.warranty_expiry)
          const today = new Date()
          const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

          if (daysUntilExpiry <= 90 && daysUntilExpiry > 0) {
            stats.expiringWarranties.push(asset)
          } else if (daysUntilExpiry <= 0) {
            stats.expiredWarranties.push(asset)
          }
        }
      })

      return stats
    } catch (error) {
      console.error("Error generating asset stats:", error)
      return {
        total: 0,
        available: 0,
        assigned: 0,
        maintenance: 0,
        retired: 0,
        totalValue: 0,
        averageValue: 0,
        byType: {},
        byStatus: {},
        byBrand: {},
        expiringWarranties: [],
        expiredWarranties: [],
      }
    }
  }

  // Asset assignment history
  static async getAssignmentHistory(assetId: number): Promise<AssetAssignment[]> {
    try {
      return await DatabaseService.findAll("asset_assignments", "asset_id = $1", [assetId])
    } catch (error) {
      console.error("Error fetching assignment history:", error)
      return []
    }
  }
}

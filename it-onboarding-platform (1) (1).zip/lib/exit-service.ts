// Exit request management service with database integration
import { DatabaseService } from "./database-service"

export interface ExitRequest {
  id: number
  employee_id: number
  employee_name?: string
  employee_email?: string
  employee_employee_id?: string
  department_name?: string
  exit_date: string
  status: "pending" | "in_progress" | "completed" | "cancelled"
  progress: number

  // Asset Return
  assets_returned: boolean
  assets_returned_date?: string

  // Software Cleanup
  office_license_revoked: boolean
  adobe_license_revoked: boolean
  vpn_access_revoked: boolean
  software_cleanup_date?: string

  // Data Deletion
  apps_deleted: boolean
  os_formatted: boolean
  data_deletion_date?: string

  // Final Communication
  final_email_sent: boolean

  notes?: string
  created_at: string
  updated_at: string
  completed_at?: string
}

export class ExitService {
  static async getAll(): Promise<ExitRequest[]> {
    try {
      const exitRequests = await DatabaseService.findAll("exit_requests")

      // Get employee details for each request
      for (const request of exitRequests) {
        const employee = await DatabaseService.findById("employees", request.employee_id)
        if (employee) {
          request.employee_name = `${employee.first_name} ${employee.last_name}`
          request.employee_email = employee.email
          request.employee_employee_id = employee.employee_id

          // Get department name
          if (employee.department_id) {
            const department = await DatabaseService.findById("departments", employee.department_id)
            request.department_name = department?.name || "Unknown"
          }
        }
      }

      return exitRequests
    } catch (error) {
      console.error("Error fetching exit requests:", error)
      return []
    }
  }

  static async create(requestData: Partial<ExitRequest>): Promise<ExitRequest> {
    try {
      const newRequest = await DatabaseService.create("exit_requests", {
        employee_id: requestData.employee_id,
        exit_date: requestData.exit_date,
        status: "pending",
        progress: 20,
        assets_returned: requestData.assets_returned || false,
        office_license_revoked: requestData.office_license_revoked || false,
        adobe_license_revoked: requestData.adobe_license_revoked || false,
        vpn_access_revoked: requestData.vpn_access_revoked || false,
        apps_deleted: requestData.apps_deleted || false,
        os_formatted: requestData.os_formatted || false,
        final_email_sent: requestData.final_email_sent || false,
        notes: requestData.notes,
      })

      return newRequest
    } catch (error) {
      console.error("Error creating exit request:", error)
      throw error
    }
  }

  static async update(id: number, updates: Partial<ExitRequest>): Promise<ExitRequest | null> {
    try {
      // Calculate progress based on completed stages
      if (
        updates.assets_returned !== undefined ||
        updates.office_license_revoked !== undefined ||
        updates.apps_deleted !== undefined ||
        updates.final_email_sent !== undefined
      ) {
        const current = await this.getById(id)
        if (current) {
          updates.progress = this.calculateProgress({
            ...current,
            ...updates,
          })

          // Update status based on progress
          if (updates.progress === 100) {
            updates.status = "completed"
            updates.completed_at = new Date().toISOString()
          } else if (updates.progress > 20) {
            updates.status = "in_progress"
          }
        }
      }

      const updatedRequest = await DatabaseService.update("exit_requests", id, updates)
      return updatedRequest
    } catch (error) {
      console.error("Error updating exit request:", error)
      return null
    }
  }

  static async getById(id: number): Promise<ExitRequest | null> {
    try {
      const request = await DatabaseService.getExitWithEmployee(id)
      if (request) {
        request.employee_name = `${request.first_name} ${request.last_name}`
        request.employee_email = request.email
        request.employee_employee_id = request.employee_id
      }
      return request
    } catch (error) {
      console.error("Error fetching exit request by ID:", error)
      return null
    }
  }

  static async getByEmployeeId(employeeId: number): Promise<ExitRequest | null> {
    try {
      const requests = await DatabaseService.findAll("exit_requests", "employee_id = $1", [employeeId])
      return requests[0] || null
    } catch (error) {
      console.error("Error fetching exit request by employee ID:", error)
      return null
    }
  }

  static calculateProgress(request: ExitRequest): number {
    let progress = 0

    // Asset Return (30%)
    if (request.assets_returned) progress += 30

    // Software Cleanup (30%)
    const softwareCleanup = [
      request.office_license_revoked,
      request.adobe_license_revoked,
      request.vpn_access_revoked,
    ].filter(Boolean).length

    if (softwareCleanup > 0) progress += Math.round((softwareCleanup / 3) * 30)

    // Data Deletion (25%)
    if (request.apps_deleted && request.os_formatted) progress += 25

    // Final Communication (15%)
    if (request.final_email_sent) progress += 15

    return Math.min(progress, 100)
  }

  // Exit statistics
  static async getExitStats(): Promise<{
    total: number
    pending: number
    inProgress: number
    completed: number
    cancelled: number
    avgProgress: number
    byDepartment: Record<string, number>
    byStatus: Record<string, number>
    recentRequests: ExitRequest[]
  }> {
    try {
      const requests = await this.getAll()
      const avgProgress = requests.length > 0 ? requests.reduce((sum, r) => sum + r.progress, 0) / requests.length : 0

      const stats = {
        total: requests.length,
        pending: requests.filter((r) => r.status === "pending").length,
        inProgress: requests.filter((r) => r.status === "in_progress").length,
        completed: requests.filter((r) => r.status === "completed").length,
        cancelled: requests.filter((r) => r.status === "cancelled").length,
        avgProgress: Math.round(avgProgress),
        byDepartment: {} as Record<string, number>,
        byStatus: {} as Record<string, number>,
        recentRequests: requests
          .filter((r) => new Date(r.created_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          .slice(0, 10),
      }

      // Group by department and status
      requests.forEach((request) => {
        const dept = request.department_name || "Unknown"
        stats.byDepartment[dept] = (stats.byDepartment[dept] || 0) + 1
        stats.byStatus[request.status] = (stats.byStatus[request.status] || 0) + 1
      })

      return stats
    } catch (error) {
      console.error("Error generating exit stats:", error)
      return {
        total: 0,
        pending: 0,
        inProgress: 0,
        completed: 0,
        cancelled: 0,
        avgProgress: 0,
        byDepartment: {},
        byStatus: {},
        recentRequests: [],
      }
    }
  }
}

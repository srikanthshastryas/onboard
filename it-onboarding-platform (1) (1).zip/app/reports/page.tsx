"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  FileText,
  Download,
  Users,
  Package,
  UserPlus,
  Mail,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  BarChart3,
} from "lucide-react"
import Link from "next/link"
import { ReportsService, type ReportData } from "@/lib/reports-service"

export default function ReportsPage() {
  const [activeReport, setActiveReport] = useState<ReportData | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const generateReport = async (type: string) => {
    setIsGenerating(true)

    // Simulate report generation delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    let report: ReportData
    switch (type) {
      case "employee":
        report = ReportsService.generateEmployeeReport()
        break
      case "asset":
        report = ReportsService.generateAssetReport()
        break
      case "onboarding":
        report = ReportsService.generateOnboardingReport()
        break
      case "email":
        report = ReportsService.generateEmailReport()
        break
      case "financial":
        report = ReportsService.generateFinancialReport()
        break
      default:
        return
    }

    setActiveReport(report)
    setIsGenerating(false)
  }

  const exportReport = (format: "csv" | "json") => {
    if (!activeReport) return

    if (format === "csv") {
      let dataToExport: any[] = []

      switch (activeReport.type) {
        case "employee":
          dataToExport = activeReport.data.employees
          break
        case "asset":
          dataToExport = activeReport.data.assets
          break
        case "onboarding":
          dataToExport = activeReport.data.onboardingRequests
          break
        case "email":
          dataToExport = activeReport.data.emails
          break
        default:
          dataToExport = [activeReport.data.stats]
      }

      ReportsService.exportToCSV(dataToExport, activeReport.type)
    } else {
      const blob = new Blob([JSON.stringify(activeReport.data, null, 2)], { type: "application/json" })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${activeReport.type}-report-${new Date().toISOString().split("T")[0]}.json`
      link.click()
      window.URL.revokeObjectURL(url)
    }
  }

  const reportTypes = [
    {
      id: "employee",
      title: "Employee Report",
      description: "Complete employee directory and statistics",
      icon: <Users className="h-6 w-6" />,
      color: "text-blue-600",
    },
    {
      id: "asset",
      title: "Asset Inventory Report",
      description: "Asset tracking and financial summary",
      icon: <Package className="h-6 w-6" />,
      color: "text-green-600",
    },
    {
      id: "onboarding",
      title: "Onboarding Report",
      description: "Employee onboarding progress tracking",
      icon: <UserPlus className="h-6 w-6" />,
      color: "text-purple-600",
    },
    {
      id: "email",
      title: "Email Activity Report",
      description: "System email notifications and logs",
      icon: <Mail className="h-6 w-6" />,
      color: "text-orange-600",
    },
    {
      id: "financial",
      title: "Financial Report",
      description: "Asset valuation and cost analysis",
      icon: <DollarSign className="h-6 w-6" />,
      color: "text-red-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-6">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
              <p className="text-gray-600">Generate comprehensive reports and export data</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Report Types */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-blue-600" />
                  Available Reports
                </CardTitle>
                <CardDescription>Select a report type to generate</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {reportTypes.map((report) => (
                  <Button
                    key={report.id}
                    variant="outline"
                    className="w-full justify-start h-auto p-4 bg-transparent"
                    onClick={() => generateReport(report.id)}
                    disabled={isGenerating}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={report.color}>{report.icon}</div>
                      <div className="text-left">
                        <p className="font-medium">{report.title}</p>
                        <p className="text-sm text-gray-500">{report.description}</p>
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Report Display */}
          <div className="lg:col-span-2">
            {isGenerating && (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
                    <p className="text-gray-600">Generating report...</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {!isGenerating && !activeReport && (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500 mb-2">No report selected</p>
                    <p className="text-sm text-gray-400">Choose a report type from the left panel</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeReport && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{activeReport.title}</CardTitle>
                      <CardDescription>
                        Generated on {new Date(activeReport.generatedAt).toLocaleString()}
                      </CardDescription>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => exportReport("csv")}>
                        <Download className="h-4 w-4 mr-2" />
                        CSV
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => exportReport("json")}>
                        <Download className="h-4 w-4 mr-2" />
                        JSON
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="summary" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="summary">Summary</TabsTrigger>
                      <TabsTrigger value="details">Details</TabsTrigger>
                    </TabsList>

                    <TabsContent value="summary" className="space-y-4">
                      {activeReport.type === "employee" && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-4 bg-blue-50 rounded-lg">
                            <p className="text-2xl font-bold text-blue-600">{activeReport.data.stats.total}</p>
                            <p className="text-sm text-blue-800">Total Employees</p>
                          </div>
                          <div className="text-center p-4 bg-green-50 rounded-lg">
                            <p className="text-2xl font-bold text-green-600">{activeReport.data.stats.active}</p>
                            <p className="text-sm text-green-800">Active</p>
                          </div>
                          <div className="text-center p-4 bg-yellow-50 rounded-lg">
                            <p className="text-2xl font-bold text-yellow-600">{activeReport.data.stats.pending}</p>
                            <p className="text-sm text-yellow-800">Pending Start</p>
                          </div>
                          <div className="text-center p-4 bg-gray-50 rounded-lg">
                            <p className="text-2xl font-bold text-gray-600">{activeReport.data.stats.exited}</p>
                            <p className="text-sm text-gray-800">Exited</p>
                          </div>
                        </div>
                      )}

                      {activeReport.type === "asset" && (
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="text-center p-4 bg-blue-50 rounded-lg">
                              <p className="text-2xl font-bold text-blue-600">{activeReport.data.stats.total}</p>
                              <p className="text-sm text-blue-800">Total Assets</p>
                            </div>
                            <div className="text-center p-4 bg-green-50 rounded-lg">
                              <p className="text-2xl font-bold text-green-600">{activeReport.data.stats.available}</p>
                              <p className="text-sm text-green-800">Available</p>
                            </div>
                            <div className="text-center p-4 bg-purple-50 rounded-lg">
                              <p className="text-2xl font-bold text-purple-600">{activeReport.data.stats.assigned}</p>
                              <p className="text-sm text-purple-800">Assigned</p>
                            </div>
                            <div className="text-center p-4 bg-red-50 rounded-lg">
                              <p className="text-2xl font-bold text-red-600">
                                ${activeReport.data.stats.totalValue.toLocaleString()}
                              </p>
                              <p className="text-sm text-red-800">Total Value</p>
                            </div>
                          </div>

                          {activeReport.data.stats.expiringWarranties.length > 0 && (
                            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                              <div className="flex items-center">
                                <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                                <p className="font-medium text-yellow-800">
                                  {activeReport.data.stats.expiringWarranties.length} warranties expiring soon
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeReport.type === "financial" && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="text-center p-6 bg-green-50 rounded-lg">
                            <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
                            <p className="text-3xl font-bold text-green-600">
                              ${activeReport.data.stats.totalAssetValue.toLocaleString()}
                            </p>
                            <p className="text-sm text-green-800">Total Asset Value</p>
                          </div>
                          <div className="text-center p-6 bg-blue-50 rounded-lg">
                            <DollarSign className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                            <p className="text-3xl font-bold text-blue-600">
                              ${Math.round(activeReport.data.stats.averageAssetValue).toLocaleString()}
                            </p>
                            <p className="text-sm text-blue-800">Average Asset Value</p>
                          </div>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="details" className="space-y-4">
                      <div className="max-h-96 overflow-y-auto">
                        <pre className="text-xs bg-gray-50 p-4 rounded-lg overflow-x-auto">
                          {JSON.stringify(activeReport.data, null, 2)}
                        </pre>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Edit, Mail, Phone, Calendar, Building, User, UserPlus, UserMinus } from "lucide-react"
import Link from "next/link"

export default function EmployeeDetails({ params }: { params: { id: string } }) {
  // Mock data - in real app, fetch based on params.id
  const employee = {
    id: params.id,
    employeeId: "EMP001",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@company.com",
    phone: "+1 (555) 123-4567",
    department: "Engineering",
    position: "Software Engineer",
    startDate: "2024-03-01",
    status: "active",
    manager: "Sarah Johnson",
    workLocation: "Hybrid",
    employmentType: "Full-time",
    salary: "$85,000",
    notes: "Experienced developer with React and Node.js expertise. Prefers morning meetings.",
    createdAt: "2024-02-15",
    lastUpdated: "2024-02-20",
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "pending_start":
        return "bg-blue-100 text-blue-800"
      case "exited":
        return "bg-gray-100 text-gray-800"
      case "inactive":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/employees">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Employees
                </Button>
              </Link>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-xl">
                    {employee.firstName[0]}
                    {employee.lastName[0]}
                  </span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    {employee.firstName} {employee.lastName}
                  </h1>
                  <p className="text-gray-600">
                    {employee.position} • {employee.department}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className={getStatusColor(employee.status)}>
                {employee.status.replace("_", " ").toUpperCase()}
              </Badge>
              <Link href={`/employees/${employee.id}/edit`}>
                <Button variant="outline">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2 text-blue-600" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Employee ID</p>
                    <p className="text-lg">{employee.employeeId}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Full Name</p>
                    <p className="text-lg">
                      {employee.firstName} {employee.lastName}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <Mail className="h-4 w-4 mr-1" />
                      Email
                    </p>
                    <p className="text-lg">{employee.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <Phone className="h-4 w-4 mr-1" />
                      Phone
                    </p>
                    <p className="text-lg">{employee.phone}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Job Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="h-5 w-5 mr-2 text-green-600" />
                  Job Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Department</p>
                    <p className="text-lg">{employee.department}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Position</p>
                    <p className="text-lg">{employee.position}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Manager</p>
                    <p className="text-lg">{employee.manager}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Employment Type</p>
                    <p className="text-lg">{employee.employmentType}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Start Date
                    </p>
                    <p className="text-lg">{new Date(employee.startDate).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Work Location</p>
                    <p className="text-lg">{employee.workLocation}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-500">Annual Salary</p>
                  <p className="text-lg">{employee.salary}</p>
                </div>
              </CardContent>
            </Card>

            {/* Additional Notes */}
            {employee.notes && (
              <Card>
                <CardHeader>
                  <CardTitle>Additional Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">{employee.notes}</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Actions Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Manage employee processes</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {employee.status === "pending_start" && (
                  <Link href={`/onboarding/new?employeeId=${employee.employeeId}`}>
                    <Button className="w-full">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Start Onboarding
                    </Button>
                  </Link>
                )}

                {employee.status === "active" && (
                  <Link href={`/exit/new?employeeId=${employee.employeeId}`}>
                    <Button variant="destructive" className="w-full">
                      <UserMinus className="h-4 w-4 mr-2" />
                      Initiate Exit
                    </Button>
                  </Link>
                )}

                <Button variant="outline" className="w-full bg-transparent">
                  <Mail className="h-4 w-4 mr-2" />
                  Send Email
                </Button>

                <Link href={`/employees/${employee.id}/edit`}>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Details
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* System Information */}
            <Card>
              <CardHeader>
                <CardTitle>System Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">Created</p>
                  <p className="text-sm">{new Date(employee.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Last Updated</p>
                  <p className="text-sm">{new Date(employee.lastUpdated).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Status</p>
                  <Badge className={getStatusColor(employee.status)}>
                    {employee.status.replace("_", " ").toUpperCase()}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

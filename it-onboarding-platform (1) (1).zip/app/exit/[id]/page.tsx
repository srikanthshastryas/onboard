"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, CheckCircle, Clock, Trash2, HardDrive, FileText, Shield, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { EmailTriggerPanel } from "@/components/email-trigger-panel"

export default function ExitDetails({ params }: { params: { id: string } }) {
  const [exitData, setExitData] = useState({
    id: params.id,
    employee: "Mike Johnson",
    employeeId: "EMP003",
    email: "mike.johnson@company.com",
    department: "Sales",
    exitDate: "2024-04-01",
    status: "in_progress",
    progress: 60,
    tasks: {
      assetsReturned: { completed: true, completedAt: "2024-03-20 14:30" },
      softwareRevoked: { completed: false, completedAt: null },
      dataDeleted: { completed: false, completedAt: null },
      systemFormatted: { completed: false, completedAt: null },
      finalEmail: { completed: false, completedAt: null },
    },
    software: {
      officeLicenseRevoked: false,
      adobeLicenseRevoked: true,
      vpnAccessRevoked: false,
    },
    returnedAssets: [
      { name: "MacBook Pro M3", serial: "MB001", type: "Laptop", returned: true },
      { name: 'Samsung 27" Monitor', serial: "SM001", type: "Monitor", returned: true },
      { name: "Logitech MX Keys", serial: "LT001", type: "Keyboard", returned: false },
    ],
  })

  const getTaskIcon = (completed: boolean) => {
    return completed ? (
      <CheckCircle className="h-5 w-5 text-green-600" />
    ) : (
      <Clock className="h-5 w-5 text-yellow-600" />
    )
  }

  const handleTaskToggle = (taskKey: keyof typeof exitData.tasks) => {
    const newCompleted = !exitData.tasks[taskKey].completed
    setExitData((prev) => ({
      ...prev,
      tasks: {
        ...prev.tasks,
        [taskKey]: {
          completed: newCompleted,
          completedAt: newCompleted ? new Date().toLocaleString() : null,
        },
      },
    }))
  }

  const handleSoftwareToggle = (softwareKey: keyof typeof exitData.software) => {
    setExitData((prev) => ({
      ...prev,
      software: {
        ...prev.software,
        [softwareKey]: !prev.software[softwareKey],
      },
    }))
  }

  const getCurrentStage = () => {
    if (!exitData.tasks.assetsReturned.completed) return "Asset Return"
    if (!exitData.tasks.softwareRevoked.completed) return "Software Cleanup"
    if (!exitData.tasks.dataDeleted.completed) return "Data Deletion"
    if (!exitData.tasks.systemFormatted.completed) return "System Formatting"
    if (!exitData.tasks.finalEmail.completed) return "Final Communication"
    return "Completed"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/exit">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Exit Requests
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{exitData.employee}</h1>
                <p className="text-gray-600">
                  {exitData.employeeId} • {exitData.department} • Exit: {exitData.exitDate}
                </p>
              </div>
            </div>
            <Badge className="bg-red-100 text-red-800">{exitData.status.replace("_", " ")}</Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Card */}
            <Card>
              <CardHeader>
                <CardTitle>Exit Progress</CardTitle>
                <CardDescription>Overall completion status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Progress</span>
                    <span className="text-sm text-gray-500">{exitData.progress}%</span>
                  </div>
                  <Progress value={exitData.progress} className="w-full" />
                  <p className="text-sm text-gray-600">
                    Current Stage: <strong>{getCurrentStage()}</strong>
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Interactive Exit Tasks */}
            <Card>
              <CardHeader>
                <CardTitle>Exit Tasks</CardTitle>
                <CardDescription>Click to update completion status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(exitData.tasks).map(([key, task]) => (
                    <div key={key} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-3">
                        {getTaskIcon(task.completed)}
                        <div>
                          <p className="font-medium capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</p>
                          {task.completedAt && <p className="text-xs text-gray-500">Completed: {task.completedAt}</p>}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={task.completed ? "default" : "secondary"}>
                          {task.completed ? "Complete" : "Pending"}
                        </Badge>
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={() => handleTaskToggle(key as keyof typeof exitData.tasks)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Interactive Software Cleanup */}
            <Card>
              <CardHeader>
                <CardTitle>Software License Cleanup</CardTitle>
                <CardDescription>Click to update revocation status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <div className="flex-1">
                      <p className="font-medium">Office License</p>
                      <Badge variant={exitData.software.officeLicenseRevoked ? "destructive" : "secondary"}>
                        {exitData.software.officeLicenseRevoked ? "Revoked" : "Active"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={exitData.software.officeLicenseRevoked}
                      onCheckedChange={() => handleSoftwareToggle("officeLicenseRevoked")}
                    />
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <FileText className="h-5 w-5 text-red-600" />
                    <div className="flex-1">
                      <p className="font-medium">Adobe License</p>
                      <Badge variant={exitData.software.adobeLicenseRevoked ? "destructive" : "secondary"}>
                        {exitData.software.adobeLicenseRevoked ? "Revoked" : "Active"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={exitData.software.adobeLicenseRevoked}
                      onCheckedChange={() => handleSoftwareToggle("adobeLicenseRevoked")}
                    />
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <Shield className="h-5 w-5 text-green-600" />
                    <div className="flex-1">
                      <p className="font-medium">VPN Access</p>
                      <Badge variant={exitData.software.vpnAccessRevoked ? "destructive" : "secondary"}>
                        {exitData.software.vpnAccessRevoked ? "Revoked" : "Active"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={exitData.software.vpnAccessRevoked}
                      onCheckedChange={() => handleSoftwareToggle("vpnAccessRevoked")}
                    />
                  </div>
                </div>

                {/* Warning for active licenses */}
                {(!exitData.software.officeLicenseRevoked || !exitData.software.vpnAccessRevoked) && (
                  <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center">
                      <AlertTriangle className="h-4 w-4 text-yellow-600 mr-2" />
                      <p className="text-yellow-800 text-sm font-medium">Active licenses detected</p>
                    </div>
                    <p className="text-yellow-700 text-sm mt-1">
                      Please revoke all software licenses before completing the exit process.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Asset Return Status */}
            <Card>
              <CardHeader>
                <CardTitle>Asset Return Status</CardTitle>
                <CardDescription>Track returned company assets</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {exitData.returnedAssets.map((asset, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <HardDrive className="h-5 w-5 text-blue-600" />
                        <div>
                          <p className="font-medium">{asset.name}</p>
                          <p className="text-sm text-gray-500">Serial: {asset.serial}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={asset.returned ? "default" : "destructive"}>
                          {asset.returned ? "Returned" : "Pending"}
                        </Badge>
                        {asset.returned && <CheckCircle className="h-4 w-4 text-green-600" />}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Email Trigger Panel */}
          <div className="space-y-6">
            <EmailTriggerPanel
              employeeName={exitData.employee}
              employeeEmail={exitData.email}
              processType="exit"
              currentStage={getCurrentStage()}
            />

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button className="w-full bg-transparent" variant="outline">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Secure Data Wipe
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  <HardDrive className="h-4 w-4 mr-2" />
                  Format Devices
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  Generate Exit Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

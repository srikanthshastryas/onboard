"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, AlertTriangle, Trash2, HardDrive, Mail, FileText, Shield } from "lucide-react"
import Link from "next/link"
import { EmployeeService, type Employee } from "@/lib/employee-service"
import { EmailTrackingService } from "@/lib/email-tracking-service"
import { EmailActivity } from "@/components/email-activity"

export default function NewExit() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [emailsSent, setEmailsSent] = useState<string[]>([])
  const [activeEmployees, setActiveEmployees] = useState<Employee[]>([])

  const [formData, setFormData] = useState({
    employeeId: "",
    exitDate: "",
    assetsReturned: false,
    appsDeleted: false,
    osFormatted: false,
    officeLicenseRevoked: false,
    adobeLicenseRevoked: false,
    vpnAccessRevoked: false,
    finalEmailSent: false,
    notes: "",
  })

  useEffect(() => {
    // Load active employees from service
    const employees = EmployeeService.getActiveEmployees()
    setActiveEmployees(employees)
  }, [])

  const sendEmail = (recipient: string, subject: string, content: string, recipientType: "employee" | "hr" | "it") => {
    EmailTrackingService.add({
      recipient,
      recipientType,
      subject,
      content,
      processType: "exit",
      processId: formData.employeeId,
    })

    setEmailsSent((prev) => [...prev, `${recipient} - ${subject}`])
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const selectedEmployee = activeEmployees.find((emp) => emp.employeeId === formData.employeeId)

      if (selectedEmployee) {
        // Update employee status to exited
        EmployeeService.update(selectedEmployee.id, { status: "exited" })

        // Send exit notifications
        sendEmail(
          selectedEmployee.email,
          "Exit process initiated - Important information",
          `Dear ${selectedEmployee.firstName} ${selectedEmployee.lastName},\n\nYour exit process has been initiated for ${formData.exitDate}.\n\nPlease ensure all company assets are returned and coordinate with IT for data backup if needed.\n\nThank you for your service.\n\nBest regards,\nHR Team`,
          "employee",
        )

        sendEmail(
          "hr@company.com",
          `Exit process started for ${selectedEmployee.firstName} ${selectedEmployee.lastName}`,
          `Exit process has been initiated for ${selectedEmployee.firstName} ${selectedEmployee.lastName}.\n\nExit Date: ${formData.exitDate}\n\nPlease coordinate final paperwork and benefits processing.`,
          "hr",
        )

        sendEmail(
          "it@company.com",
          `Asset recovery and system cleanup required for ${selectedEmployee.firstName} ${selectedEmployee.lastName}`,
          `Please initiate asset recovery and system cleanup for ${selectedEmployee.firstName} ${selectedEmployee.lastName}.\n\nExit Date: ${formData.exitDate}\n\nTasks:\n- Collect all assigned assets\n- Revoke software licenses\n- Disable system accounts\n- Secure data deletion\n- Format devices\n\nSoftware Cleanup Status:\n- Office License: ${formData.officeLicenseRevoked ? "Revoked" : "Pending"}\n- Adobe License: ${formData.adobeLicenseRevoked ? "Revoked" : "Pending"}\n- VPN Access: ${formData.vpnAccessRevoked ? "Revoked" : "Pending"}`,
          "it",
        )

        alert(
          `✅ Exit request created successfully!\n\n📧 ${emailsSent.length + 3} email notifications sent:\n- Exit notification to ${selectedEmployee.firstName} ${selectedEmployee.lastName}\n- Notification to HR team\n- Cleanup request to IT team\n\nEmployee status updated to "Exited"`,
        )

        setTimeout(() => {
          router.push("/exit")
        }, 2000)
      } else {
        alert("❌ Selected employee not found. Please try again.")
      }
    } catch (error) {
      console.error("Error creating exit request:", error)
      alert("❌ Error creating exit request. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const selectedEmployee = activeEmployees.find((emp) => emp.employeeId === formData.employeeId)

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-6">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Employee Exit Process</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
            <p className="text-red-800 font-medium">Important: Employee Exit Process</p>
          </div>
          <p className="text-red-700 text-sm mt-1">
            This process will initiate the complete offboarding workflow including asset recovery, software cleanup,
            data deletion, and system access removal.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employee Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Employee Selection</CardTitle>
              <CardDescription>Select the employee who is leaving the organization</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="employeeId">Employee *</Label>
                <Select
                  value={formData.employeeId}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, employeeId: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {activeEmployees.map((employee) => (
                      <SelectItem key={employee.employeeId} value={employee.employeeId}>
                        {employee.firstName} {employee.lastName} - {employee.employeeId} ({employee.department})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {activeEmployees.length === 0 && (
                  <p className="text-sm text-gray-500 mt-1">No active employees found. Please add employees first.</p>
                )}
              </div>

              <div>
                <Label htmlFor="exitDate">Exit Date *</Label>
                <Input
                  id="exitDate"
                  type="date"
                  value={formData.exitDate}
                  onChange={(e) => setFormData((prev) => ({ ...prev, exitDate: e.target.value }))}
                  required
                />
              </div>

              {selectedEmployee && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-blue-800 text-sm font-medium">Selected Employee Details:</p>
                  <p className="text-blue-700 text-sm">
                    {selectedEmployee.firstName} {selectedEmployee.lastName} ({selectedEmployee.employeeId}) -{" "}
                    {selectedEmployee.department}
                  </p>
                  <p className="text-blue-700 text-sm">Email: {selectedEmployee.email}</p>
                  <p className="text-blue-700 text-sm">Position: {selectedEmployee.position}</p>
                  <p className="text-blue-700 text-sm">Manager: {selectedEmployee.manager}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Asset Recovery */}
          <Card>
            <CardHeader>
              <CardTitle>Asset Recovery</CardTitle>
              <CardDescription>Confirm all company assets have been returned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="assetsReturned"
                    checked={formData.assetsReturned}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, assetsReturned: checked as boolean }))
                    }
                  />
                  <Label htmlFor="assetsReturned" className="flex items-center">
                    <HardDrive className="h-4 w-4 mr-2 text-blue-600" />
                    All assets returned and verified
                  </Label>
                </div>

                <div className="ml-6 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">Typical assets to be returned:</p>
                  <ul className="text-sm space-y-1">
                    <li>• Laptop (MacBook Pro / Dell XPS / etc.)</li>
                    <li>• External Monitor</li>
                    <li>• Keyboard and Mouse</li>
                    <li>• Cables and Adapters</li>
                    <li>• Company Phone (if applicable)</li>
                    <li>• Access Cards and Keys</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Software Cleanup */}
          <Card>
            <CardHeader>
              <CardTitle>Software License Management</CardTitle>
              <CardDescription>Confirm software licenses and installations are properly handled</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="officeLicenseRevoked"
                  checked={formData.officeLicenseRevoked}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, officeLicenseRevoked: checked as boolean }))
                  }
                />
                <Label htmlFor="officeLicenseRevoked" className="flex items-center">
                  <FileText className="h-4 w-4 mr-2 text-blue-600" />
                  Microsoft Office license revoked and reassigned
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="adobeLicenseRevoked"
                  checked={formData.adobeLicenseRevoked}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, adobeLicenseRevoked: checked as boolean }))
                  }
                />
                <Label htmlFor="adobeLicenseRevoked" className="flex items-center">
                  <FileText className="h-4 w-4 mr-2 text-red-600" />
                  Adobe licenses deactivated
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="vpnAccessRevoked"
                  checked={formData.vpnAccessRevoked}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, vpnAccessRevoked: checked as boolean }))
                  }
                />
                <Label htmlFor="vpnAccessRevoked" className="flex items-center">
                  <Shield className="h-4 w-4 mr-2 text-green-600" />
                  VPN access revoked and credentials disabled
                </Label>
              </div>

              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 text-red-600 mr-2" />
                  <p className="text-red-800 text-sm font-medium">Software License Management Checklist</p>
                </div>
                <ul className="text-red-700 text-sm mt-2 space-y-1">
                  <li>• Office 365 license reassigned to available pool</li>
                  <li>• Adobe Creative Cloud subscription cancelled</li>
                  <li>• VPN user account disabled and removed</li>
                  <li>• All software installations documented for audit</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Data & System Cleanup */}
          <Card>
            <CardHeader>
              <CardTitle>Data & System Cleanup</CardTitle>
              <CardDescription>Confirm data deletion and system formatting</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="appsDeleted"
                  checked={formData.appsDeleted}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, appsDeleted: checked as boolean }))}
                />
                <Label htmlFor="appsDeleted" className="flex items-center">
                  <Trash2 className="h-4 w-4 mr-2 text-red-600" />
                  All related apps and data deleted
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="osFormatted"
                  checked={formData.osFormatted}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, osFormatted: checked as boolean }))}
                />
                <Label htmlFor="osFormatted" className="flex items-center">
                  <HardDrive className="h-4 w-4 mr-2 text-orange-600" />
                  Operating system formatted and reset
                </Label>
              </div>

              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 text-yellow-600 mr-2" />
                  <p className="text-yellow-800 text-sm font-medium">Data Deletion Checklist</p>
                </div>
                <ul className="text-yellow-700 text-sm mt-2 space-y-1">
                  <li>• Email accounts deactivated</li>
                  <li>• Cloud storage access revoked</li>
                  <li>• Application data removed</li>
                  <li>• Local files securely deleted</li>
                  <li>• System accounts disabled</li>
                  <li>• Browser data and saved passwords cleared</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Final Communication */}
          <Card>
            <CardHeader>
              <CardTitle>Final Communication</CardTitle>
              <CardDescription>Email notifications and final updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="finalEmailSent"
                  checked={formData.finalEmailSent}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, finalEmailSent: checked as boolean }))
                  }
                />
                <Label htmlFor="finalEmailSent" className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-green-600" />
                  Final email update sent to HR and IT
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Notes</CardTitle>
              <CardDescription>Any special notes or issues encountered</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Enter any additional notes about the exit process..."
                value={formData.notes}
                onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Email Activity */}
          <EmailActivity processType="exit" processId={formData.employeeId} />

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <Link href="/">
              <Button variant="outline" disabled={isSubmitting}>
                Cancel
              </Button>
            </Link>
            <Button type="submit" variant="destructive" disabled={isSubmitting || !formData.employeeId}>
              {isSubmitting ? "Processing..." : "Process Employee Exit"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}

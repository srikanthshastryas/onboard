"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Package, DollarSign, Calendar, FileText } from "lucide-react"
import Link from "next/link"
import { AssetService } from "@/lib/asset-service"
import { EmailTrackingService } from "@/lib/email-tracking-service"

export default function NewAsset() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    type: "",
    brand: "",
    model: "",
    serialNumber: "",
    status: "available" as const,
    purchaseDate: "",
    purchasePrice: "",
    warrantyExpiry: "",
    location: "",
    notes: "",
  })

  const assetTypes = [
    "Laptop",
    "Desktop",
    "Monitor",
    "Keyboard",
    "Mouse",
    "Tablet",
    "Phone",
    "Printer",
    "Dock",
    "Headset",
  ]
  const brands = {
    Laptop: ["Apple", "Dell", "Lenovo", "HP", "ASUS", "Microsoft"],
    Desktop: ["Dell", "HP", "Lenovo", "Apple", "Custom Build"],
    Monitor: ["Samsung", "LG", "Dell", "ASUS", "BenQ", "Acer"],
    Keyboard: ["Logitech", "Apple", "Microsoft", "Corsair", "Razer"],
    Mouse: ["Logitech", "Apple", "Microsoft", "Razer", "SteelSeries"],
    Tablet: ["Apple", "Samsung", "Microsoft", "Lenovo"],
    Phone: ["Apple", "Samsung", "Google", "OnePlus"],
    Printer: ["HP", "Canon", "Epson", "Brother"],
    Dock: ["CalDigit", "Anker", "Belkin", "Dell"],
    Headset: ["Sony", "Bose", "Logitech", "Jabra", "Apple"],
  }
  const locations = ["IT Storage Room A", "IT Storage Room B", "Reception Desk", "Conference Room", "Manager Office"]

  const handleTypeChange = (type: string) => {
    setFormData((prev) => ({
      ...prev,
      type,
      brand: "", // Reset brand when type changes
      serialNumber: "", // Reset serial number
    }))
  }

  const handleBrandChange = (brand: string) => {
    setFormData((prev) => ({
      ...prev,
      brand,
      serialNumber: prev.serialNumber || AssetService.generateSerialNumber(prev.type, brand),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Generate serial number if not provided
      const serialNumber = formData.serialNumber || AssetService.generateSerialNumber(formData.type, formData.brand)

      // Create the asset record
      const newAsset = AssetService.create({
        type: formData.type,
        brand: formData.brand,
        model: formData.model,
        serialNumber,
        status: formData.status,
        purchaseDate: formData.purchaseDate,
        purchasePrice: formData.purchasePrice ? Number.parseFloat(formData.purchasePrice) : undefined,
        warrantyExpiry: formData.warrantyExpiry,
        location: formData.location,
        notes: formData.notes,
      })

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Send notification emails
      EmailTrackingService.add({
        recipient: "it@company.com",
        recipientType: "it",
        subject: `New asset added to inventory - ${formData.brand} ${formData.model}`,
        content: `A new asset has been added to the inventory system.

Asset Details:
- Type: ${formData.type}
- Brand: ${formData.brand}
- Model: ${formData.model}
- Serial Number: ${serialNumber}
- Status: ${formData.status}
- Location: ${formData.location}
- Purchase Date: ${formData.purchaseDate}
- Purchase Price: ${formData.purchasePrice ? `$${formData.purchasePrice}` : "Not specified"}
- Warranty Expiry: ${formData.warrantyExpiry || "Not specified"}

The asset is now available for assignment to employees.`,
        processType: "employee_added", // Using existing process type for now
        processId: serialNumber,
      })

      if (formData.purchasePrice && Number.parseFloat(formData.purchasePrice) > 1000) {
        EmailTrackingService.add({
          recipient: "finance@company.com",
          recipientType: "hr", // Using hr type for finance
          subject: `High-value asset purchase recorded - ${formData.brand} ${formData.model}`,
          content: `A high-value asset purchase has been recorded in the system.

Asset Details:
- Type: ${formData.type}
- Brand: ${formData.brand}
- Model: ${formData.model}
- Serial Number: ${serialNumber}
- Purchase Price: $${formData.purchasePrice}
- Purchase Date: ${formData.purchaseDate}
- Warranty Expiry: ${formData.warrantyExpiry || "Not specified"}

Please ensure this purchase is properly recorded in the financial system.`,
          processType: "employee_added",
          processId: serialNumber,
        })
      }

      alert(`✅ Asset added successfully!

Asset Details:
- Type: ${formData.type}
- Brand: ${formData.brand}
- Model: ${formData.model}
- Serial Number: ${serialNumber}
- Status: ${formData.status}

📧 Notifications sent to IT team${formData.purchasePrice && Number.parseFloat(formData.purchasePrice) > 1000 ? " and Finance team" : ""}

The asset is now available in the inventory.`)

      // Redirect to assets list
      setTimeout(() => {
        router.push("/assets")
      }, 2000)
    } catch (error) {
      console.error("Error adding asset:", error)
      alert("❌ Error adding asset. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const availableBrands = formData.type ? brands[formData.type as keyof typeof brands] || [] : []

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-6">
            <Link href="/assets">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Assets
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Add New Asset</h1>
              <p className="text-gray-600">Add a new asset to the inventory system</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Asset Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2 text-blue-600" />
                Asset Information
              </CardTitle>
              <CardDescription>Basic asset details and specifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Asset Type *</Label>
                  <Select value={formData.type} onValueChange={handleTypeChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select asset type" />
                    </SelectTrigger>
                    <SelectContent>
                      {assetTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="brand">Brand *</Label>
                  <Select value={formData.brand} onValueChange={handleBrandChange} disabled={!formData.type}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select brand" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableBrands.map((brand) => (
                        <SelectItem key={brand} value={brand}>
                          {brand}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="model">Model *</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))}
                    placeholder="MacBook Pro M3, XPS 13, etc."
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="serialNumber">Serial Number</Label>
                  <Input
                    id="serialNumber"
                    value={formData.serialNumber}
                    onChange={(e) => setFormData((prev) => ({ ...prev, serialNumber: e.target.value }))}
                    placeholder="Auto-generated if empty"
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave empty to auto-generate</p>
                </div>
              </div>

              <div>
                <Label htmlFor="location">Location *</Label>
                <Select
                  value={formData.location}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, location: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select storage location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Purchase Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                Purchase Information
              </CardTitle>
              <CardDescription>Financial and warranty details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="purchaseDate" className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Purchase Date
                  </Label>
                  <Input
                    id="purchaseDate"
                    type="date"
                    value={formData.purchaseDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, purchaseDate: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="purchasePrice">Purchase Price (USD)</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    step="0.01"
                    value={formData.purchasePrice}
                    onChange={(e) => setFormData((prev) => ({ ...prev, purchasePrice: e.target.value }))}
                    placeholder="1299.99"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="warrantyExpiry">Warranty Expiry Date</Label>
                <Input
                  id="warrantyExpiry"
                  type="date"
                  value={formData.warrantyExpiry}
                  onChange={(e) => setFormData((prev) => ({ ...prev, warrantyExpiry: e.target.value }))}
                />
              </div>

              {formData.purchasePrice && Number.parseFloat(formData.purchasePrice) > 1000 && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 text-yellow-600 mr-2" />
                    <p className="text-yellow-800 text-sm font-medium">High-Value Asset</p>
                  </div>
                  <p className="text-yellow-700 text-sm mt-1">
                    This asset is valued over $1,000. Finance team will be notified for proper accounting.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Additional Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2 text-purple-600" />
                Additional Information
              </CardTitle>
              <CardDescription>Notes and special requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  placeholder="Any special notes, configurations, or requirements..."
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <Link href="/assets">
              <Button variant="outline" disabled={isSubmitting}>
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting}>
              <Package className="h-4 w-4 mr-2" />
              {isSubmitting ? "Adding Asset..." : "Add Asset"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}

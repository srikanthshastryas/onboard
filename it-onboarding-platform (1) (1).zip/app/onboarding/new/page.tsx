"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Mail, CheckCircle, FileText, Archive, Shield } from "lucide-react"
import Link from "next/link"
import { OnboardingService } from "@/lib/onboarding-service"
import { EmailTrackingService } from "@/lib/email-tracking-service"
import { EmailActivity } from "@/components/email-activity"

export default function NewOnboarding() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [emailsSent, setEmailsSent] = useState<string[]>([])

  const [formData, setFormData] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
    department: "",
    position: "",
    startDate: "",
    hrApproval: false,
    selectedAssets: [] as string[],
    emailAccounts: false,
    systemAccess: false,
    officeInstallation: false,
    adobeReader: false,
    compressionTool: false,
    vpnSetup: false,
    notes: "",
  })

  const departments = ["Engineering", "Marketing", "Sales", "Human Resources", "Finance", "Operations"]

  const availableAssets = [
    { id: "1", name: "Dell XPS 13 - DL001", type: "Laptop", available: true },
    { id: "2", name: "MacBook Pro M3 - MB001", type: "Laptop", available: true },
    { id: "3", name: 'Samsung 27" 4K - SM001', type: "Monitor", available: true },
    { id: "4", name: "Logitech MX Keys - LT001", type: "Keyboard", available: true },
    { id: "5", name: "Logitech MX Master 3 - LT002", type: "Mouse", available: true },
  ]

  const handleAssetToggle = (assetId: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedAssets: prev.selectedAssets.includes(assetId)
        ? prev.selectedAssets.filter((id) => id !== assetId)
        : [...prev.selectedAssets, assetId],
    }))
  }

  const sendEmail = (recipient: string, subject: string, content: string, recipientType: "employee" | "hr" | "it") => {
    EmailTrackingService.add({
      recipient,
      recipientType,
      subject,
      content,
      processType: "onboarding",
      processId: formData.employeeId,
    })

    setEmailsSent((prev) => [...prev, `${recipient} - ${subject}`])
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const employeeName = `${formData.firstName} ${formData.lastName}`

      // Create the onboarding request record
      const onboardingRequest = OnboardingService.create({
        employee: employeeName,
        employeeId: formData.employeeId,
        email: formData.email,
        department: formData.department,
        position: formData.position,
        startDate: formData.startDate,
        hrApproval: formData.hrApproval,
        assetsAssigned: formData.selectedAssets.length,
        softwareInstalled: [
          formData.officeInstallation,
          formData.adobeReader,
          formData.compressionTool,
          formData.vpnSetup,
        ].filter(Boolean).length,
        selectedAssets: formData.selectedAssets,
        softwareRequirements: {
          officeInstallation: formData.officeInstallation,
          adobeReader: formData.adobeReader,
          compressionTool: formData.compressionTool,
          vpnSetup: formData.vpnSetup,
        },
        notes: formData.notes,
      })

      // Store in localStorage for demo purposes (in real app, this would be API call)
      const existingRequests = JSON.parse(localStorage.getItem("onboardingRequests") || "[]")
      existingRequests.push(onboardingRequest)
      localStorage.setItem("onboardingRequests", JSON.stringify(existingRequests))

      // Update the sendEmail calls:
      sendEmail(
        formData.email,
        "Welcome to the team! Your onboarding has started",
        `Dear ${employeeName},\n\nWelcome to our organization! Your onboarding process has been initiated for your start date of ${formData.startDate}.\n\nYou will receive updates as we prepare your workspace and accounts.\n\nBest regards,\nIT Team`,
        "employee",
      )

      sendEmail(
        "hr@company.com",
        `New onboarding request for ${employeeName}`,
        `A new onboarding request has been created for ${employeeName} in the ${formData.department} department.\n\nStart Date: ${formData.startDate}\nEmployee Email: ${formData.email}\n\nPlease review and approve the request.`,
        "hr",
      )

      sendEmail(
        "it@company.com",
        `Asset and software setup required for ${employeeName}`,
        `Please prepare assets and software for new employee ${employeeName}.\n\nDepartment: ${formData.department}\nStart Date: ${formData.startDate}\n\nSoftware Requirements:\n- Office: ${formData.officeInstallation ? "Required" : "Not required"}\n- Adobe Reader: ${formData.adobeReader ? "Required" : "Not required"}\n- Compression Tool: ${formData.compressionTool ? "Required" : "Not required"}\n- VPN: ${formData.vpnSetup ? "Required" : "Not required"}\n\nAssets to assign: ${formData.selectedAssets.length} items\n\nEverything should be ready by the start date.`,
        "it",
      )

      alert(
        `✅ Onboarding request created successfully!\n\nRequest ID: ${onboardingRequest.id}\n📧 ${emailsSent.length + 3} email notifications sent:\n- Welcome email to ${employeeName}\n- Notification to HR team\n- Setup request to IT team\n\nThe request now appears in the onboarding list.`,
      )

      // Redirect after success
      setTimeout(() => {
        router.push("/onboarding")
      }, 2000)
    } catch (error) {
      console.error("Error creating onboarding request:", error)
      alert("❌ Error creating onboarding request. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const softwareProgress = [
    formData.officeInstallation,
    formData.adobeReader,
    formData.compressionTool,
    formData.vpnSetup,
  ].filter(Boolean).length

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-6">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">New Employee Onboarding</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employee Information */}
          <Card>
            <CardHeader>
              <CardTitle>Employee Information</CardTitle>
              <CardDescription>Basic details about the new employee</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="employeeId">Employee ID *</Label>
                  <Input
                    id="employeeId"
                    value={formData.employeeId}
                    onChange={(e) => setFormData((prev) => ({ ...prev, employeeId: e.target.value }))}
                    placeholder="EMP001"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="startDate">Start Date *</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData((prev) => ({ ...prev, startDate: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, firstName: e.target.value }))}
                    placeholder="John"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, lastName: e.target.value }))}
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="john.doe@company.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="position">Position *</Label>
                  <Input
                    id="position"
                    value={formData.position}
                    onChange={(e) => setFormData((prev) => ({ ...prev, position: e.target.value }))}
                    placeholder="Software Engineer"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="department">Department *</Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, department: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* HR Approval */}
          <Card>
            <CardHeader>
              <CardTitle>HR Approval</CardTitle>
              <CardDescription>Confirmation from HR department</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="hrApproval"
                  checked={formData.hrApproval}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, hrApproval: checked as boolean }))}
                />
                <Label htmlFor="hrApproval" className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                  HR has approved this onboarding request
                </Label>
              </div>
              {!formData.hrApproval && (
                <p className="text-sm text-amber-600 mt-2">
                  ⚠️ HR approval is required before proceeding with asset assignment
                </p>
              )}
            </CardContent>
          </Card>

          {/* Asset Assignment */}
          <Card>
            <CardHeader>
              <CardTitle>Asset Assignment</CardTitle>
              <CardDescription>
                Select assets to assign to the new employee ({formData.selectedAssets.length} selected)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {availableAssets.map((asset) => (
                  <div key={asset.id} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <Checkbox
                      id={`asset-${asset.id}`}
                      checked={formData.selectedAssets.includes(asset.id)}
                      onCheckedChange={() => handleAssetToggle(asset.id)}
                      disabled={!asset.available}
                    />
                    <Label htmlFor={`asset-${asset.id}`} className="flex-1 cursor-pointer">
                      <div className="flex justify-between items-center">
                        <span className={asset.available ? "" : "text-gray-400"}>{asset.name}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">{asset.type}</span>
                          {asset.available ? (
                            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Available</span>
                          ) : (
                            <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">Assigned</span>
                          )}
                        </div>
                      </div>
                    </Label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Software Installation */}
          <Card>
            <CardHeader>
              <CardTitle>Software Installation Requirements</CardTitle>
              <CardDescription>Required software packages ({softwareProgress}/4 selected)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <Checkbox
                    id="officeInstallation"
                    checked={formData.officeInstallation}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, officeInstallation: checked as boolean }))
                    }
                  />
                  <Label htmlFor="officeInstallation" className="flex items-center cursor-pointer">
                    <FileText className="h-4 w-4 mr-2 text-blue-600" />
                    Microsoft Office Suite
                  </Label>
                </div>

                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <Checkbox
                    id="adobeReader"
                    checked={formData.adobeReader}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, adobeReader: checked as boolean }))}
                  />
                  <Label htmlFor="adobeReader" className="flex items-center cursor-pointer">
                    <FileText className="h-4 w-4 mr-2 text-red-600" />
                    Adobe Reader DC
                  </Label>
                </div>

                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <Checkbox
                    id="compressionTool"
                    checked={formData.compressionTool}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, compressionTool: checked as boolean }))
                    }
                  />
                  <Label htmlFor="compressionTool" className="flex items-center cursor-pointer">
                    <Archive className="h-4 w-4 mr-2 text-orange-600" />
                    WinRAR / 7-Zip
                  </Label>
                </div>

                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <Checkbox
                    id="vpnSetup"
                    checked={formData.vpnSetup}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, vpnSetup: checked as boolean }))}
                  />
                  <Label htmlFor="vpnSetup" className="flex items-center cursor-pointer">
                    <Shield className="h-4 w-4 mr-2 text-green-600" />
                    VPN Client Setup
                  </Label>
                </div>
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-blue-800 text-sm font-medium mb-2">📋 Software Installation Checklist:</p>
                <ul className="text-blue-700 text-sm space-y-1">
                  <li>• Microsoft Office 365 or Office 2021</li>
                  <li>• Adobe Acrobat Reader DC (latest version)</li>
                  <li>• WinRAR or 7-Zip for file compression</li>
                  <li>• Company VPN client with user credentials</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Access & Accounts */}
          <Card>
            <CardHeader>
              <CardTitle>Access & Accounts</CardTitle>
              <CardDescription>Email accounts and system access setup</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="emailAccounts"
                  checked={formData.emailAccounts}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, emailAccounts: checked as boolean }))}
                />
                <Label htmlFor="emailAccounts" className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-blue-600" />
                  Email accounts created and shared
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="systemAccess"
                  checked={formData.systemAccess}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, systemAccess: checked as boolean }))}
                />
                <Label htmlFor="systemAccess" className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                  System access granted
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Notes</CardTitle>
              <CardDescription>Any special requirements or notes</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Enter any additional notes or special requirements..."
                value={formData.notes}
                onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Email Activity */}
          <EmailActivity processType="onboarding" processId={formData.employeeId} />

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <Link href="/">
              <Button variant="outline" disabled={isSubmitting}>
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Onboarding Request"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}

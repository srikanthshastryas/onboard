"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, CheckCircle, Clock, FileText, Archive, Shield, Laptop, Monitor } from "lucide-react"
import Link from "next/link"
import { EmailTriggerPanel } from "@/components/email-trigger-panel"

export default function OnboardingDetails({ params }: { params: { id: string } }) {
  const [onboardingData, setOnboardingData] = useState({
    id: params.id,
    employee: "John Doe",
    employeeId: "EMP001",
    email: "john.doe@company.com",
    department: "Engineering",
    position: "Software Engineer",
    startDate: "2024-03-01",
    status: "in_progress",
    progress: 75,
    stages: {
      hrApproval: { completed: true, completedAt: "2024-02-16 10:30" },
      assetAssignment: { completed: true, completedAt: "2024-02-17 14:20" },
      softwareInstallation: { completed: false, completedAt: null },
      accountCreation: { completed: true, completedAt: "2024-02-18 09:15" },
      finalSetup: { completed: false, completedAt: null },
    },
    software: {
      officeInstallation: true,
      adobeReader: false,
      compressionTool: true,
      vpnSetup: false,
    },
    assignedAssets: [
      { name: "MacBook Pro M3", serial: "MB001", type: "Laptop" },
      { name: 'Samsung 27" Monitor', serial: "SM001", type: "Monitor" },
    ],
  })

  const getStageIcon = (completed: boolean) => {
    return completed ? (
      <CheckCircle className="h-5 w-5 text-green-600" />
    ) : (
      <Clock className="h-5 w-5 text-yellow-600" />
    )
  }

  const handleSoftwareToggle = (softwareKey: keyof typeof onboardingData.software) => {
    setOnboardingData((prev) => ({
      ...prev,
      software: {
        ...prev.software,
        [softwareKey]: !prev.software[softwareKey],
      },
    }))
  }

  const handleStageToggle = (stageKey: keyof typeof onboardingData.stages) => {
    const newCompleted = !onboardingData.stages[stageKey].completed
    setOnboardingData((prev) => ({
      ...prev,
      stages: {
        ...prev.stages,
        [stageKey]: {
          completed: newCompleted,
          completedAt: newCompleted ? new Date().toLocaleString() : null,
        },
      },
    }))
  }

  const getCurrentStage = () => {
    if (!onboardingData.stages.hrApproval.completed) return "HR Approval"
    if (!onboardingData.stages.assetAssignment.completed) return "Asset Assignment"
    if (!onboardingData.stages.softwareInstallation.completed) return "Software Installation"
    if (!onboardingData.stages.accountCreation.completed) return "Account Creation"
    if (!onboardingData.stages.finalSetup.completed) return "Final Setup"
    return "Completed"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <Link href="/onboarding">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Onboarding
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{onboardingData.employee}</h1>
                <p className="text-gray-600">
                  {onboardingData.employeeId} • {onboardingData.department}
                </p>
              </div>
            </div>
            <Badge className="bg-blue-100 text-blue-800">{onboardingData.status.replace("_", " ")}</Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Card */}
            <Card>
              <CardHeader>
                <CardTitle>Onboarding Progress</CardTitle>
                <CardDescription>Overall completion status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Progress</span>
                    <span className="text-sm text-gray-500">{onboardingData.progress}%</span>
                  </div>
                  <Progress value={onboardingData.progress} className="w-full" />
                  <p className="text-sm text-gray-600">
                    Current Stage: <strong>{getCurrentStage()}</strong>
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Interactive Process Stages */}
            <Card>
              <CardHeader>
                <CardTitle>Process Stages</CardTitle>
                <CardDescription>Click to update completion status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(onboardingData.stages).map(([key, stage]) => (
                    <div key={key} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-3">
                        {getStageIcon(stage.completed)}
                        <div>
                          <p className="font-medium capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</p>
                          {stage.completedAt && <p className="text-xs text-gray-500">Completed: {stage.completedAt}</p>}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={stage.completed ? "default" : "secondary"}>
                          {stage.completed ? "Complete" : "Pending"}
                        </Badge>
                        <Checkbox
                          checked={stage.completed}
                          onCheckedChange={() => handleStageToggle(key as keyof typeof onboardingData.stages)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Interactive Software Installation */}
            <Card>
              <CardHeader>
                <CardTitle>Software Installation Status</CardTitle>
                <CardDescription>Click to update installation status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <div className="flex-1">
                      <p className="font-medium">Microsoft Office</p>
                      <Badge variant={onboardingData.software.officeInstallation ? "default" : "secondary"}>
                        {onboardingData.software.officeInstallation ? "Installed" : "Pending"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={onboardingData.software.officeInstallation}
                      onCheckedChange={() => handleSoftwareToggle("officeInstallation")}
                    />
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <FileText className="h-5 w-5 text-red-600" />
                    <div className="flex-1">
                      <p className="font-medium">Adobe Reader</p>
                      <Badge variant={onboardingData.software.adobeReader ? "default" : "secondary"}>
                        {onboardingData.software.adobeReader ? "Installed" : "Pending"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={onboardingData.software.adobeReader}
                      onCheckedChange={() => handleSoftwareToggle("adobeReader")}
                    />
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <Archive className="h-5 w-5 text-orange-600" />
                    <div className="flex-1">
                      <p className="font-medium">WinRAR/7-Zip</p>
                      <Badge variant={onboardingData.software.compressionTool ? "default" : "secondary"}>
                        {onboardingData.software.compressionTool ? "Installed" : "Pending"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={onboardingData.software.compressionTool}
                      onCheckedChange={() => handleSoftwareToggle("compressionTool")}
                    />
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                    <Shield className="h-5 w-5 text-green-600" />
                    <div className="flex-1">
                      <p className="font-medium">VPN Client</p>
                      <Badge variant={onboardingData.software.vpnSetup ? "default" : "secondary"}>
                        {onboardingData.software.vpnSetup ? "Configured" : "Pending"}
                      </Badge>
                    </div>
                    <Checkbox
                      checked={onboardingData.software.vpnSetup}
                      onCheckedChange={() => handleSoftwareToggle("vpnSetup")}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Assigned Assets */}
            <Card>
              <CardHeader>
                <CardTitle>Assigned Assets</CardTitle>
                <CardDescription>Hardware assigned to this employee</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {onboardingData.assignedAssets.map((asset, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {asset.type === "Laptop" ? (
                          <Laptop className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Monitor className="h-5 w-5 text-green-600" />
                        )}
                        <div>
                          <p className="font-medium">{asset.name}</p>
                          <p className="text-sm text-gray-500">Serial: {asset.serial}</p>
                        </div>
                      </div>
                      <Badge variant="outline">{asset.type}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Email Trigger Panel */}
          <div className="space-y-6">
            <EmailTriggerPanel
              employeeName={onboardingData.employee}
              employeeEmail={onboardingData.email}
              processType="onboarding"
              currentStage={getCurrentStage()}
            />

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button className="w-full bg-transparent" variant="outline">
                  Generate Report
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  Add More Assets
                </Button>
                <Button className="w-full bg-transparent" variant="outline">
                  Schedule Follow-up
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Laptop, UserPlus, UserMinus, Settings, Bell, FileText } from "lucide-react"
import { EmailTrackingService } from "@/lib/email-tracking-service"

export default function Dashboard() {
  const [notifications, setNotifications] = useState([
    { id: 1, message: "John Doe onboarding completed", type: "success", time: "2 hours ago" },
    { id: 2, message: "MacBook Pro assigned to Jane Smith", type: "info", time: "4 hours ago" },
    { id: 3, message: "Mike Johnson exit process initiated", type: "warning", time: "1 day ago" },
  ])

  const [emailCount, setEmailCount] = useState(0)

  useEffect(() => {
    const emails = EmailTrackingService.getAll()
    setEmailCount(emails.length)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Settings className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">IT Onboarding Platform</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="h-6 w-6 text-gray-600" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {notifications.length}
                </span>
              </div>
              <nav className="flex space-x-4">
                <Link href="/employees">
                  <Button variant="ghost">Employees</Button>
                </Link>
                <Link href="/assets">
                  <Button variant="ghost">Assets</Button>
                </Link>
                <Link href="/emails">
                  <Button variant="ghost">Emails</Button>
                </Link>
                <Link href="/reports">
                  <Button variant="ghost">Reports</Button>
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">127</div>
                <p className="text-xs text-muted-foreground">+12 from last month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Available Assets</CardTitle>
                <Laptop className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45</div>
                <p className="text-xs text-muted-foreground">Ready for assignment</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Onboarding</CardTitle>
                <UserPlus className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">Awaiting approval</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Exit Requests</CardTitle>
                <UserMinus className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">In progress</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Emails Sent</CardTitle>
                <Bell className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{emailCount}</div>
                <p className="text-xs text-muted-foreground">System notifications</p>
              </CardContent>
            </Card>
          </div>

          {/* Action Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserPlus className="h-5 w-5 mr-2 text-green-600" />
                  Employee Onboarding
                </CardTitle>
                <CardDescription>Start the onboarding process for new employees</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Create onboarding requests, assign assets, install software, and track approval status
                </p>
                <div className="flex space-x-2">
                  <Link href="/onboarding/new">
                    <Button>New Onboarding</Button>
                  </Link>
                  <Link href="/onboarding">
                    <Button variant="outline">View All</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserMinus className="h-5 w-5 mr-2 text-red-600" />
                  Employee Exit
                </CardTitle>
                <CardDescription>Manage employee exit process and asset recovery</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Handle asset returns, software cleanup, data deletion, and system cleanup
                </p>
                <div className="flex space-x-2">
                  <Link href="/exit/new">
                    <Button variant="destructive">New Exit Request</Button>
                  </Link>
                  <Link href="/exit">
                    <Button variant="outline">View All</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-purple-600" />
                  Reports & Analytics
                </CardTitle>
                <CardDescription>Generate comprehensive reports and export data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Employee reports, asset inventory, financial summaries, and email activity logs
                </p>
                <div className="flex space-x-2">
                  <Link href="/reports">
                    <Button>Generate Reports</Button>
                  </Link>
                  <Link href="/emails">
                    <Button variant="outline">View Emails</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest onboarding and exit activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`flex items-center justify-between p-4 rounded-lg ${
                      notification.type === "success"
                        ? "bg-green-50"
                        : notification.type === "info"
                          ? "bg-blue-50"
                          : "bg-yellow-50"
                    }`}
                  >
                    <div className="flex items-center">
                      {notification.type === "success" && <UserPlus className="h-4 w-4 text-green-600 mr-2" />}
                      {notification.type === "info" && <Laptop className="h-4 w-4 text-blue-600 mr-2" />}
                      {notification.type === "warning" && <UserMinus className="h-4 w-4 text-yellow-600 mr-2" />}
                      <span className="text-sm">{notification.message}</span>
                    </div>
                    <span className="text-xs text-gray-500">{notification.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

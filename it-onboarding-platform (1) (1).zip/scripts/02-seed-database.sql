-- Seed data for IT Onboarding Platform

-- Insert departments
INSERT INTO departments (name, description, manager_name, budget) VALUES 
('Engineering', 'Software development and technical teams', 'Sarah Johnson', 500000.00),
('Marketing', 'Marketing and brand management', 'Michael Brown', 200000.00),
('Sales', 'Sales and business development', 'Lisa Davis', 300000.00),
('Human Resources', 'HR and people operations', 'Robert Taylor', 150000.00),
('Finance', 'Financial planning and accounting', 'Jennifer Wilson', 180000.00),
('Operations', 'Business operations and support', 'David Miller', 250000.00);

-- Insert software licenses
INSERT INTO software_licenses (software_name, license_type, total_licenses, assigned_licenses, cost_per_license, renewal_date, vendor) VALUES 
('Microsoft Office 365', 'subscription', 150, 127, 12.50, '2024-12-31', 'Microsoft'),
('Adobe Acrobat Pro', 'subscription', 50, 23, 19.99, '2024-11-30', 'Adobe'),
('WinRAR', 'perpetual', 200, 180, 29.00, NULL, 'RARLAB'),
('VPN Client Pro', 'subscription', 200, 145, 8.99, '2024-10-15', 'VPN Corp'),
('Slack Business', 'subscription', 200, 156, 8.00, '2024-09-30', 'Slack Technologies'),
('Zoom Pro', 'subscription', 100, 89, 14.99, '2024-08-15', 'Zoom Video Communications');

-- Insert employees
INSERT INTO employees (employee_id, first_name, last_name, email, phone, department_id, position, start_date, status, manager, work_location, employment_type, salary, notes) VALUES 
('EMP001', 'John', 'Doe', 'john.doe@company.com', '+1 (555) 123-4567', 1, 'Software Engineer', '2024-03-01', 'active', 'Sarah Johnson', 'Hybrid', 'Full-time', '$85,000', 'Experienced developer with React and Node.js expertise'),
('EMP002', 'Jane', 'Smith', 'jane.smith@company.com', '+1 (555) 234-5678', 2, 'Marketing Manager', '2024-03-15', 'active', 'Michael Brown', 'Remote', 'Full-time', '$75,000', 'Digital marketing specialist'),
('EMP003', 'Mike', 'Johnson', 'mike.johnson@company.com', '+1 (555) 345-6789', 3, 'Sales Representative', '2024-04-01', 'exited', 'Lisa Davis', 'New York Office', 'Full-time', '$65,000', 'B2B sales experience'),
('EMP004', 'Sarah', 'Wilson', 'sarah.wilson@company.com', '+1 (555) 456-7890', 5, 'Financial Analyst', '2024-04-15', 'active', 'Jennifer Wilson', 'San Francisco Office', 'Full-time', '$70,000', 'CPA certified'),
('EMP005', 'Tom', 'Brown', 'tom.brown@company.com', '+1 (555) 567-8901', 2, 'Content Marketing Specialist', '2024-05-01', 'pending_start', 'Michael Brown', 'Remote', 'Full-time', '$60,000', 'Content creation and SEO expertise'),
('EMP006', 'Lisa', 'Garcia', 'lisa.garcia@company.com', '+1 (555) 678-9012', 1, 'Senior Developer', '2024-05-15', 'pending_start', 'Sarah Johnson', 'Hybrid', 'Full-time', '$95,000', 'Full-stack developer with 8 years experience'),
('EMP007', 'David', 'Lee', 'david.lee@company.com', '+1 (555) 789-0123', 6, 'Operations Manager', '2024-06-01', 'pending_start', 'David Miller', 'London Office', 'Full-time', '$80,000', 'Operations and process improvement specialist');

-- Insert assets
INSERT INTO assets (asset_type, brand, model, serial_number, status, assigned_to_id, purchase_date, purchase_price, warranty_expiry, location, notes) VALUES 
('Laptop', 'Dell', 'XPS 13', 'DL001', 'available', NULL, '2024-01-15', 1299.00, '2027-01-15', 'IT Storage Room A', 'High-performance ultrabook'),
('Laptop', 'Apple', 'MacBook Pro M3', 'MB001', 'assigned', 1, '2024-02-20', 2499.00, '2027-02-20', 'Assigned to Employee', 'High-performance laptop for development work'),
('Laptop', 'Lenovo', 'ThinkPad X1', 'LN001', 'available', NULL, '2024-01-10', 1599.00, '2027-01-10', 'IT Storage Room B', 'Business laptop with excellent keyboard'),
('Monitor', 'Samsung', '27" 4K', 'SM001', 'assigned', 2, '2024-01-25', 399.00, '2026-01-25', 'Assigned to Employee', '4K resolution for design work'),
('Monitor', 'LG', '24" FHD', 'LG001', 'available', NULL, '2024-02-01', 199.00, '2026-02-01', 'IT Storage Room A', 'Standard office monitor'),
('Keyboard', 'Logitech', 'MX Keys', 'LT001', 'available', NULL, '2024-01-30', 99.00, '2026-01-30', 'IT Storage Room A', 'Wireless mechanical keyboard'),
('Mouse', 'Logitech', 'MX Master 3', 'LT002', 'maintenance', NULL, '2024-01-30', 79.00, '2026-01-30', 'IT Repair Center', 'Scroll wheel issue - under repair'),
('Laptop', 'Apple', 'MacBook Air M2', 'MB002', 'available', NULL, '2024-03-01', 1199.00, '2027-03-01', 'IT Storage Room A', 'Lightweight laptop for general use'),
('Monitor', 'Dell', '32" 4K', 'DL002', 'available', NULL, '2024-03-10', 599.00, '2027-03-10', 'IT Storage Room B', 'Large 4K monitor for development'),
('Keyboard', 'Apple', 'Magic Keyboard', 'AP001', 'assigned', 1, '2024-03-15', 129.00, '2026-03-15', 'Assigned to Employee', 'Wireless keyboard for Mac users');

-- Insert onboarding requests
INSERT INTO onboarding_requests (employee_id, status, progress, hr_approval, hr_approved_by, hr_approval_date, assets_assigned, office_installation, adobe_reader, compression_tool, vpn_setup, email_accounts_created, system_access_granted, notes) VALUES 
(1, 'completed', 100, TRUE, 'Robert Taylor', '2024-02-16 10:30:00', TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'Completed successfully'),
(2, 'completed', 100, TRUE, 'Robert Taylor', '2024-02-28 14:20:00', TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, 'Adobe Reader not required for role'),
(4, 'in_progress', 75, TRUE, 'Robert Taylor', '2024-04-10 09:15:00', TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, 'VPN setup pending'),
(5, 'pending', 20, FALSE, NULL, NULL, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, 'Awaiting HR approval'),
(6, 'pending', 20, FALSE, NULL, NULL, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, 'Awaiting HR approval'),
(7, 'pending', 20, FALSE, NULL, NULL, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, 'Awaiting HR approval');

-- Insert exit requests
INSERT INTO exit_requests (employee_id, exit_date, status, progress, assets_returned, office_license_revoked, adobe_license_revoked, vpn_access_revoked, apps_deleted, os_formatted, final_email_sent, notes) VALUES 
(3, '2024-04-01', 'completed', 100, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'Exit completed successfully');

-- Insert asset assignments (history)
INSERT INTO asset_assignments (asset_id, employee_id, assigned_date, status, notes) VALUES 
(2, 1, '2024-03-01 09:00:00', 'active', 'MacBook Pro assigned for development work'),
(4, 2, '2024-03-15 10:30:00', 'active', '4K monitor for design work'),
(10, 1, '2024-03-15 10:35:00', 'active', 'Magic Keyboard for Mac setup');

-- Insert software assignments
INSERT INTO software_assignments (employee_id, software_license_id, assigned_date, status, notes) VALUES 
(1, 1, '2024-03-01 09:00:00', 'active', 'Office 365 for development work'),
(1, 4, '2024-03-01 09:05:00', 'active', 'VPN access for remote work'),
(2, 1, '2024-03-15 10:00:00', 'active', 'Office 365 for marketing work'),
(2, 2, '2024-03-15 10:05:00', 'active', 'Adobe Acrobat for document management'),
(4, 1, '2024-04-15 08:30:00', 'active', 'Office 365 for financial analysis'),
(3, 1, '2024-02-01 09:00:00', 'revoked', 'Office 365 revoked upon exit'),
(3, 4, '2024-02-01 09:05:00', 'revoked', 'VPN access revoked upon exit');

-- Insert sample email logs
INSERT INTO email_logs (recipient_email, recipient_type, subject, content, process_type, process_id, status, sent_at) VALUES 
('john.doe@company.com', 'employee', 'Welcome to the team! Your onboarding has started', 'Dear John Doe, Welcome to our organization! Your onboarding process has been initiated...', 'onboarding', 1, 'sent', '2024-02-15 08:00:00'),
('hr@company.com', 'hr', 'New onboarding request for John Doe', 'A new onboarding request has been created for John Doe in the Engineering department...', 'onboarding', 1, 'sent', '2024-02-15 08:01:00'),
('it@company.com', 'it', 'Asset and software setup required for John Doe', 'Please prepare assets and software for new employee John Doe...', 'onboarding', 1, 'sent', '2024-02-15 08:02:00'),
('jane.smith@company.com', 'employee', 'Welcome to the team! Your onboarding has started', 'Dear Jane Smith, Welcome to our organization! Your onboarding process has been initiated...', 'onboarding', 2, 'sent', '2024-02-28 09:00:00'),
('mike.johnson@company.com', 'employee', 'Exit process initiated - Important information', 'Dear Mike Johnson, Your exit process has been initiated for 2024-04-01...', 'exit', 1, 'sent', '2024-03-20 14:30:00'),
('hr@company.com', 'hr', 'Exit process started for Mike Johnson', 'Exit process has been initiated for Mike Johnson...', 'exit', 1, 'sent', '2024-03-20 14:31:00'),
('it@company.com', 'it', 'Asset recovery and system cleanup required for Mike Johnson', 'Please initiate asset recovery and system cleanup for Mike Johnson...', 'exit', 1, 'sent', '2024-03-20 14:32:00');

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES 
('company_name', 'TechCorp Inc.', 'Company name for email templates'),
('hr_email', 'hr@company.com', 'HR team email address'),
('it_email', 'it@company.com', 'IT team email address'),
('finance_email', 'finance@company.com', 'Finance team email address'),
('default_onboarding_duration', '14', 'Default onboarding duration in days'),
('asset_depreciation_rate', '0.02', 'Monthly asset depreciation rate'),
('warranty_alert_days', '90', 'Days before warranty expiry to show alert'),
('email_retention_days', '365', 'Days to retain email logs');

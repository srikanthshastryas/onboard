-- IT Onboarding Platform Database Schema
-- Drop existing tables if they exist (in reverse dependency order)
DROP TABLE IF EXISTS software_assignments CASCADE;
DROP TABLE IF EXISTS asset_assignments CASCADE;
DROP TABLE IF EXISTS email_logs CASCADE;
DROP TABLE IF EXISTS exit_requests CASCADE;
DROP TABLE IF EXISTS onboarding_requests CASCADE;
DROP TABLE IF EXISTS assets CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS departments CASCADE;
DROP TABLE IF EXISTS software_licenses CASCADE;
DROP TABLE IF EXISTS system_settings CASCADE;

-- Create departments table
CREATE TABLE departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    manager_name VARCHAR(100),
    budget DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create employees table
CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    department_id INTEGER REFERENCES departments(id),
    position VARCHAR(100),
    start_date DATE,
    end_date DATE,
    status VARCHAR(20) DEFAULT 'pending_start' CHECK (status IN ('active', 'pending_start', 'exited', 'inactive')),
    manager VARCHAR(100),
    work_location VARCHAR(100),
    employment_type VARCHAR(50) DEFAULT 'Full-time',
    salary VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create assets table
CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    asset_type VARCHAR(50) NOT NULL,
    brand VARCHAR(50),
    model VARCHAR(100),
    serial_number VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'available' CHECK (status IN ('available', 'assigned', 'maintenance', 'retired')),
    assigned_to_id INTEGER REFERENCES employees(id),
    image_url TEXT,
    purchase_date DATE,
    purchase_price DECIMAL(10,2),
    warranty_expiry DATE,
    location VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create software_licenses table
CREATE TABLE software_licenses (
    id SERIAL PRIMARY KEY,
    software_name VARCHAR(100) NOT NULL,
    license_type VARCHAR(50) NOT NULL CHECK (license_type IN ('subscription', 'perpetual', 'site')),
    total_licenses INTEGER NOT NULL,
    assigned_licenses INTEGER DEFAULT 0,
    available_licenses INTEGER GENERATED ALWAYS AS (total_licenses - assigned_licenses) STORED,
    cost_per_license DECIMAL(10,2),
    renewal_date DATE,
    vendor VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create onboarding_requests table
CREATE TABLE onboarding_requests (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    
    -- HR Approval
    hr_approval BOOLEAN DEFAULT FALSE,
    hr_approved_by VARCHAR(100),
    hr_approval_date TIMESTAMP,
    
    -- Asset Assignment
    assets_assigned BOOLEAN DEFAULT FALSE,
    assets_assigned_date TIMESTAMP,
    
    -- Software Installation
    office_installation BOOLEAN DEFAULT FALSE,
    adobe_reader BOOLEAN DEFAULT FALSE,
    compression_tool BOOLEAN DEFAULT FALSE,
    vpn_setup BOOLEAN DEFAULT FALSE,
    software_completed_date TIMESTAMP,
    
    -- Account Creation
    email_accounts_created BOOLEAN DEFAULT FALSE,
    system_access_granted BOOLEAN DEFAULT FALSE,
    accounts_completed_date TIMESTAMP,
    
    -- Final Setup
    final_setup_completed BOOLEAN DEFAULT FALSE,
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Create exit_requests table
CREATE TABLE exit_requests (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id) NOT NULL,
    exit_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    
    -- Asset Return
    assets_returned BOOLEAN DEFAULT FALSE,
    assets_returned_date TIMESTAMP,
    
    -- Software Cleanup
    office_license_revoked BOOLEAN DEFAULT FALSE,
    adobe_license_revoked BOOLEAN DEFAULT FALSE,
    vpn_access_revoked BOOLEAN DEFAULT FALSE,
    software_cleanup_date TIMESTAMP,
    
    -- Data Deletion
    apps_deleted BOOLEAN DEFAULT FALSE,
    os_formatted BOOLEAN DEFAULT FALSE,
    data_deletion_date TIMESTAMP,
    
    -- Final Communication
    final_email_sent BOOLEAN DEFAULT FALSE,
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Create asset_assignments table (for tracking asset history)
CREATE TABLE asset_assignments (
    id SERIAL PRIMARY KEY,
    asset_id INTEGER REFERENCES assets(id) NOT NULL,
    employee_id INTEGER REFERENCES employees(id) NOT NULL,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    returned_date TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'returned')),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create software_assignments table
CREATE TABLE software_assignments (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id) NOT NULL,
    software_license_id INTEGER REFERENCES software_licenses(id) NOT NULL,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    revoked_date TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'revoked')),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create email_logs table
CREATE TABLE email_logs (
    id SERIAL PRIMARY KEY,
    recipient_email VARCHAR(255) NOT NULL,
    recipient_type VARCHAR(20) NOT NULL CHECK (recipient_type IN ('employee', 'hr', 'it', 'manager')),
    subject VARCHAR(255) NOT NULL,
    content TEXT,
    process_type VARCHAR(20) NOT NULL CHECK (process_type IN ('onboarding', 'exit', 'employee_added', 'asset_assigned')),
    process_id INTEGER,
    status VARCHAR(20) DEFAULT 'sent' CHECK (status IN ('sent', 'pending', 'failed')),
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create system_settings table
CREATE TABLE system_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_employees_employee_id ON employees(employee_id);
CREATE INDEX idx_employees_email ON employees(email);
CREATE INDEX idx_employees_status ON employees(status);
CREATE INDEX idx_employees_department ON employees(department_id);

CREATE INDEX idx_assets_serial_number ON assets(serial_number);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_assigned_to ON assets(assigned_to_id);

CREATE INDEX idx_onboarding_employee ON onboarding_requests(employee_id);
CREATE INDEX idx_onboarding_status ON onboarding_requests(status);

CREATE INDEX idx_exit_employee ON exit_requests(employee_id);
CREATE INDEX idx_exit_status ON exit_requests(status);

CREATE INDEX idx_email_logs_process ON email_logs(process_type, process_id);
CREATE INDEX idx_email_logs_recipient ON email_logs(recipient_type);
CREATE INDEX idx_email_logs_sent_at ON email_logs(sent_at);

-- Create triggers for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_assets_updated_at BEFORE UPDATE ON assets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON departments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_software_licenses_updated_at BEFORE UPDATE ON software_licenses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_onboarding_requests_updated_at BEFORE UPDATE ON onboarding_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_exit_requests_updated_at BEFORE UPDATE ON exit_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

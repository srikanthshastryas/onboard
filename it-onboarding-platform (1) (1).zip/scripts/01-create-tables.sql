-- Create departments table
CREATE TABLE IF NOT EXISTS departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create assets table
CREATE TABLE IF NOT EXISTS assets (
    id SERIAL PRIMARY KEY,
    asset_type VARCHAR(50) NOT NULL,
    brand VARCHAR(50),
    model VARCHAR(100),
    serial_number VARCHAR(100) UNIQUE,
    status VARCHAR(20) DEFAULT 'available', -- available, assigned, maintenance, retired
    image_url TEXT,
    purchase_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create employees table
CREATE TABLE IF NOT EXISTS employees (
    id SERIAL PRIMARY KEY,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    department_id INTEGER REFERENCES departments(id),
    position VARCHAR(100),
    start_date DATE,
    status VARCHAR(20) DEFAULT 'active', -- active, inactive, exited
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create onboarding_requests table
CREATE TABLE IF NOT EXISTS onboarding_requests (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id),
    hr_approval BOOLEAN DEFAULT FALSE,
    hr_approved_by VARCHAR(100),
    hr_approval_date TIMESTAMP,
    assigned_assets TEXT[], -- Array of asset IDs
    email_accounts_created BOOLEAN DEFAULT FALSE,
    system_access_granted BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending', -- pending, in_progress, completed
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Create exit_requests table
CREATE TABLE IF NOT EXISTS exit_requests (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id),
    exit_date DATE,
    assets_returned BOOLEAN DEFAULT FALSE,
    apps_deleted BOOLEAN DEFAULT FALSE,
    os_formatted BOOLEAN DEFAULT FALSE,
    final_email_sent BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending', -- pending, in_progress, completed
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Create email_logs table
CREATE TABLE IF NOT EXISTS email_logs (
    id SERIAL PRIMARY KEY,
    recipient_email VARCHAR(255) NOT NULL,
    recipient_type VARCHAR(20) NOT NULL, -- candidate, hr, it
    subject VARCHAR(255) NOT NULL,
    content TEXT,
    request_type VARCHAR(20) NOT NULL, -- onboarding, exit
    request_id INTEGER,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample departments
INSERT INTO departments (name) VALUES 
('Engineering'),
('Marketing'),
('Sales'),
('Human Resources'),
('Finance'),
('Operations');

-- Insert sample assets
INSERT INTO assets (asset_type, brand, model, serial_number, status, purchase_date) VALUES 
('Laptop', 'Dell', 'XPS 13', 'DL001', 'available', '2024-01-15'),
('Laptop', 'MacBook', 'Pro M3', 'MB001', 'available', '2024-02-20'),
('Laptop', 'Lenovo', 'ThinkPad X1', 'LN001', 'available', '2024-01-10'),
('Monitor', 'Samsung', '27" 4K', 'SM001', 'available', '2024-01-25'),
('Monitor', 'LG', '24" FHD', 'LG001', 'available', '2024-02-01'),
('Keyboard', 'Logitech', 'MX Keys', 'LT001', 'available', '2024-01-30'),
('Mouse', 'Logitech', 'MX Master 3', 'LT002', 'available', '2024-01-30');

-- Insert sample employees
INSERT INTO employees (employee_id, first_name, last_name, email, department_id, position, start_date) VALUES 
('EMP001', 'John', 'Doe', 'john.doe@company.com', 1, 'Software Engineer', '2024-03-01'),
('EMP002', 'Jane', 'Smith', 'jane.smith@company.com', 2, 'Marketing Manager', '2024-03-15'),
('EMP003', 'Mike', 'Johnson', 'mike.johnson@company.com', 3, 'Sales Representative', '2024-04-01');

-- Add software installation columns to onboarding_requests table
ALTER TABLE onboarding_requests ADD COLUMN IF NOT EXISTS office_installation BOOLEAN DEFAULT FALSE;
ALTER TABLE onboarding_requests ADD COLUMN IF NOT EXISTS adobe_reader BOOLEAN DEFAULT FALSE;
ALTER TABLE onboarding_requests ADD COLUMN IF NOT EXISTS compression_tool BOOLEAN DEFAULT FALSE;
ALTER TABLE onboarding_requests ADD COLUMN IF NOT EXISTS vpn_setup BOOLEAN DEFAULT FALSE;

-- Add software cleanup columns to exit_requests table
ALTER TABLE exit_requests ADD COLUMN IF NOT EXISTS office_license_revoked BOOLEAN DEFAULT FALSE;
ALTER TABLE exit_requests ADD COLUMN IF NOT EXISTS adobe_license_revoked BOOLEAN DEFAULT FALSE;
ALTER TABLE exit_requests ADD COLUMN IF NOT EXISTS vpn_access_revoked BOOLEAN DEFAULT FALSE;

-- Create software_licenses table for tracking
CREATE TABLE IF NOT EXISTS software_licenses (
    id SERIAL PRIMARY KEY,
    software_name VARCHAR(100) NOT NULL,
    license_type VARCHAR(50) NOT NULL, -- subscription, perpetual, site
    total_licenses INTEGER NOT NULL,
    assigned_licenses INTEGER DEFAULT 0,
    available_licenses INTEGER GENERATED ALWAYS AS (total_licenses - assigned_licenses) STORED,
    cost_per_license DECIMAL(10,2),
    renewal_date DATE,
    vendor VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample software licenses
INSERT INTO software_licenses (software_name, license_type, total_licenses, assigned_licenses, cost_per_license, renewal_date, vendor) VALUES 
('Microsoft Office 365', 'subscription', 150, 127, 12.50, '2024-12-31', 'Microsoft'),
('Adobe Acrobat Pro', 'subscription', 50, 23, 19.99, '2024-11-30', 'Adobe'),
('WinRAR', 'perpetual', 200, 180, 29.00, NULL, 'RARLAB'),
('VPN Client Pro', 'subscription', 200, 145, 8.99, '2024-10-15', 'VPN Corp');

-- Create software_assignments table
CREATE TABLE IF NOT EXISTS software_assignments (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id),
    software_license_id INTEGER REFERENCES software_licenses(id),
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    revoked_date TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active' -- active, revoked
);
